package vehicles;

import java.text.DecimalFormat;

public  class Vehicle {
    protected double fuelQuantity;
    protected double fuelConsumptionInLitersPerKm;
    public Vehicle(double fuelQuantity, double fuelConsumptionInLitersPerKm) {
        this.fuelQuantity = fuelQuantity;
        this.fuelConsumptionInLitersPerKm = fuelConsumptionInLitersPerKm;
    }

    public double getFuelQuantity() {
        return fuelQuantity;
    }

    public void setFuelQuantity(double fuelQuantity) {
        this.fuelQuantity = fuelQuantity;
    }

    public double getFuelConsumptionInLitersPerKm() {
        return fuelConsumptionInLitersPerKm;
    }

    public void setFuelConsumptionInLitersPerKm(double fuelConsumptionInLitersPerKm) {
        this.fuelConsumptionInLitersPerKm = fuelConsumptionInLitersPerKm;
    }

    public String  driving(double km){

        double fuelNeeded=km*fuelConsumptionInLitersPerKm;

        if(fuelNeeded>this.fuelQuantity){
            return String.format("%s needs refueling",this.getClass().getSimpleName());
        }
        this.fuelQuantity=this.fuelQuantity-fuelNeeded;

        DecimalFormat decimalFormat=new DecimalFormat("##.##");

        return String.format("%s travelled %s km",this.getClass().getSimpleName(),decimalFormat.format(km));
    }

    public  void refueling(double fuel){
        this.fuelQuantity+=fuel;
    }

    @Override
    public String toString() {
        return String.format("%s: %.2f",getClass().getSimpleName(),fuelQuantity);
    }

}
