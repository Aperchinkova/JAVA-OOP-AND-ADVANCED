package vehicles;

public class Car extends Vehicle{

    private static final double FUEL_CONSUMPTION_AC=0.9;

    public Car(double fuelQuantity, double fuelConsumptionInLitersPerKm) {
        super(fuelQuantity, fuelConsumptionInLitersPerKm);
        this.fuelConsumptionInLitersPerKm=fuelConsumptionInLitersPerKm+FUEL_CONSUMPTION_AC;
    }

}
