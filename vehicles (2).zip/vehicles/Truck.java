package vehicles;

public class Truck extends Vehicle {
    private final static  double FUEL_CONSUMPTION_AC=1.6;
    private final static double REFILL_PERCENTAGE=0.95;

    public Truck(double fuelQuantity, double fuelConsumptionInLitersPerKm) {
        super(fuelQuantity, fuelConsumptionInLitersPerKm);
        this.fuelConsumptionInLitersPerKm=fuelConsumptionInLitersPerKm+FUEL_CONSUMPTION_AC;
    }

    @Override
    public void refueling(double fuel) {

        fuel=fuel*REFILL_PERCENTAGE;
        //this.fuelQuantity+=fuel;
        super.refueling(fuel);

    }

}
