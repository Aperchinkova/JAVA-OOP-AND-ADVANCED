package vehicles;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        //creates a car
        String[] input = scanner.nextLine().split("\\s+");
        Vehicle car = createVehicle(input);

        //creates a vehicle
        input = scanner.nextLine().split("\\s+");
        Vehicle truck=createVehicle(input);

        int n = Integer.parseInt(scanner.nextLine());

        Map<String,Vehicle> vehicles=new LinkedHashMap();
        vehicles.put("Car",car);
        vehicles.put("Truck",truck);
        for (int i=0;i<n;i++){
            input=scanner.nextLine().split("\\s+");
            String type=input[1];
            switch (input[0]){
                case "Drive":
                    double km=Double.parseDouble(input[2]);
                    System.out.println(vehicles.get(type).driving(km));
                    break;
                case "Refuel":
                    double fuel=Double.parseDouble(input[2]);
                   vehicles.get(type).refueling(fuel);
                    break;
            }
        }
        vehicles.values().stream().forEach(System.out::println);
    }

    private static Vehicle createVehicle(String[] input) {

        double fuelQuantity=Double.parseDouble(input[1]);
        double consumption=Double.parseDouble(input[2]);
        String type=input[0];
        Vehicle vehicle=null;

        switch (type){
            case "Car":
                vehicle=new Car(fuelQuantity,consumption);
                break;
            case "Truck":
                vehicle=new Truck(fuelQuantity,consumption);
                break;
        }
        return vehicle;
    }
}
