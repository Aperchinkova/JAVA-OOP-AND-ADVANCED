package goldDigger.models.operation;

import goldDigger.models.discoverer.Discoverer;
import goldDigger.models.museum.BaseMuseum;
import goldDigger.models.museum.Museum;
import goldDigger.models.spot.Spot;
import goldDigger.models.spot.SpotImpl;

import java.util.ArrayDeque;
import java.util.Collection;
import java.util.Deque;

public class OperationImpl implements Operation{

    @Override
    public void startOperation(Spot spot, Collection<Discoverer> discoverers) {


        //•	They add the exhibit to their museum. The exhibit should then be removed from the state.
        //•	Discoverers cannot continue collecting exhibits if their energy drops to 0.
        //o	If their energy drops to 0, the next discoverer starts inspecting.

        //The BaseMuseum class holds a collection of exhibits. It should be instantiated.
        //The SpotImpl class holds information about the exhibits that can be found and inspected.

        for(Discoverer discoverer:discoverers){
            if(discoverer.getEnergy()<0){
                return;
            }
        }

        Deque<Discoverer> discovererDeque=new ArrayDeque<>(discoverers);
        Collection<String> nz=spot.getExhibits();
        Deque<String> spots=new ArrayDeque<>(nz);

        Discoverer discoverer=discovererDeque.poll();
        String exhibit=spots.poll();
        while (discoverer!=null && exhibit!=null){
            if(discoverer.canDig()){
                discoverer.dig();
                discoverer.getMuseum().getExhibits().add(exhibit);
                exhibit=spots.poll();
            }
            if(discoverer.getEnergy()<0){
                discoverer=discovererDeque.poll();
            }
        }
    }
}
