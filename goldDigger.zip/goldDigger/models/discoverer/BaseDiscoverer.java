package goldDigger.models.discoverer;

import goldDigger.common.ExceptionMessages;
import goldDigger.models.museum.Museum;

public abstract class BaseDiscoverer implements Discoverer {

    private String name;
    private double energy;
    private Museum museum;

    public BaseDiscoverer(String name, double energy) {
        this.setName(name);
        this.setEnergy(energy);
    }

    @Override
    public String getName() {
        return name;
    }

    private void setName(String name) {
        if(name==null || name.trim().isEmpty()){
            throw new NullPointerException(ExceptionMessages.DISCOVERER_NAME_NULL_OR_EMPTY);
        }
        this.name = name;
    }

    @Override
    public double getEnergy() {
        return energy;
    }

    private void setEnergy(double energy) {
        if(energy<0){
            throw new IllegalArgumentException(ExceptionMessages.DISCOVERER_ENERGY_LESS_THAN_ZERO);
        }
        this.energy = energy;
    }

    @Override
    public Museum getMuseum() {
        return museum;
    }

    private void setMuseum(Museum museum) {
        this.museum = museum;
    }
    @Override
     public  void dig(){
        //•	The method decreases the discoverer's energy by 15 units.
        //•	The energy value should not drop below zero.
        //•	Set the value to be zero if the energy value goes below zero.
        this.energy=Math.max(0,this.energy-15);
    }

    @Override
    public boolean canDig(){
        return energy>0;
    }
}
