package goldDigger.repositories;

import goldDigger.models.spot.Spot;

import java.util.Collection;
import java.util.Collections;
import java.util.Map;

public class SpotRepository implements Repository<Spot> {
    private Map<String,Spot> spots;

    @Override
    public Collection<Spot> getCollection() {
        return Collections.unmodifiableCollection(spots.values());
    }

    @Override
    public void add(Spot spot) {
        spots.putIfAbsent(spot.getName(), spot);
    }

    @Override
    public boolean remove(Spot spot) {
        return spots.remove(spot.getName())!=null;
    }

    @Override
    public Spot byName(String name) {
        return spots.getOrDefault(name, null);

    }
}
