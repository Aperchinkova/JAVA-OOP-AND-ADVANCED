package ExamPreparation;

import javax.imageio.plugins.tiff.ExifInteroperabilityTagSet;
import java.util.*;

public class ThePianist {
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        int countPieces=Integer.parseInt(scanner.nextLine());
        Map<String, List<String>> piecesMap=new LinkedHashMap<>();
        for (int piece=1;piece<=countPieces;piece++)
        {
            String[] pieceData= scanner.nextLine().split("\\|");
            String pieceName=pieceData[0];
            String composer=pieceData[1];
            String tone=pieceData[2];
            List<String> pieceInfo=new ArrayList<>();
            pieceInfo.add(composer);
            pieceInfo.add(tone);
            piecesMap.put(pieceName,pieceInfo);
        }
        String command= scanner.nextLine();
        while(!command.equals("Stop"))
        {
            if(command.contains("Add"))
            {
                //Add|Sonata No.2|Chopin|B Minor
                String pieceName=command.split("\\|")[1];
                String composer=command.split("\\|")[2];
                String tone=command.split("\\|")[3];
                if(piecesMap.containsKey(pieceName))
                {
                    System.out.println(pieceName+" is already in the collection!");
                }else{
                    List<String> info=new ArrayList<>();
                    info.add(composer);
                    info.add(tone);
                    piecesMap.put(pieceName,info);
                    System.out.println(pieceName+" by "+composer+" in "+ tone+" added to the collection!");
                }
            }
            else if(command.contains("Remove"))
            {
                //Remove|Clair de Lune
                String piece=command.split("\\|")[1];
                if(piecesMap.containsKey(piece)){
                    piecesMap.remove(piece);
                    System.out.printf("Successfully removed %s!%n",piece);
                }else{
                    System.out.printf("Invalid operation! %s does not exist in the collection.%n",piece);
                }
            }
            else if(command.contains("ChangeKey"))
            {
                //ChangeKey|Moonlight Sonata|C# Major
                String piece=command.split("\\|")[1];
                String newTone=command.split("\\|")[2];
                if(!piecesMap.containsKey(piece))
                {
                    System.out.printf("Invalid operation! %s does not exist in the collection.%n", piece);
                }else{
                    List<String> currentInfo=piecesMap.get(piece);
                    currentInfo.remove(1);//composer
                    currentInfo.add(newTone);
                    piecesMap.put(piece,currentInfo);
                    System.out.printf("Changed the key of %s to %s!%n",piece,newTone);
                }
            }
            command= scanner.nextLine();
        }
        //пиеса -> списък с информация ([0] -> композитор, [1] -> тоналност)
        //"{Piece} -> Composer: {composer}, Key: {key}"
        //entry.getKey() -> име на пиесата
        //entry.getValue() -> {composer, tone}.get(0) -> composer
        //entry.getValue() -> {composer, tone}.get(1) -> tone
        piecesMap.entrySet()////всички записи
                .forEach(entry-> System.out.printf("%s -> Composer: %s, Key: %s%n",entry.getKey(),entry.getValue().get(0),entry.getValue().get(1)));
    }
}
