package OrderByAge;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;

import static java.util.Comparator.*;

public class Main {
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        String input= scanner.nextLine();
        List<Person> order=new ArrayList<>();
        while(!input.equals("End"))
        {
            String firstName = input.split(" ")[0];
            String id = input.split(" ")[1];
            int age = Integer.parseInt(input.split(" ")[2]);
            Person person=new Person(firstName,id,age);
            order.add(person);
            input=scanner.nextLine();
        }
        order.sort(Comparator.comparing(Person :: getAge));
        for (Person person:order) {
            System.out.printf("%s with ID: %s is %d years old.%n",person.getFirstname(),person.getId(),person.getAge());
        }
    }
}
