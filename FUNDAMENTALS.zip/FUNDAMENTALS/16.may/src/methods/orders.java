package methods;

import java.util.Scanner;

public class orders {
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        String product=scanner.nextLine();
        int quantity=Integer.parseInt(scanner.nextLine());
        switch(product)
        {
            case "coffee":
                price(quantity,1.5);
                break;
            case "water":
                price(quantity,1.0);
                break;
            case "coke":
                price(quantity,1.4);
                break;
            case "snacks":
                price(quantity,2.0);
                break;
        }
    }
    public static void price(int quantity,double pricePerProduct)
    {
        double totalSum=quantity*pricePerProduct;
        System.out.printf("%.2f",totalSum);
    }
}
