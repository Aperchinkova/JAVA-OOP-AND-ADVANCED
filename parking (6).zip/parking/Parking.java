package parking;

import java.util.ArrayList;
import java.util.List;

public class Parking {
    public List<Car> data;
    private String type;
    private int capacity;
    public Parking(String type, int capacity) {
        this.type = type;
        this.capacity = capacity;
        this.data=new ArrayList<>();
    }
    public void add(Car car){
        if(this.data.size()<capacity){
            data.add(car);
        }
    }
    public boolean remove(String manufacturer, String model){
        for(Car car:data){
            if(car.getManufacturer().equals(manufacturer) && car.getModel().equals(model)){
                data.remove(car);
                return true;
            }
        }
        return false;
    }
    public Car getLatestCar(){
        /*
        int oldest=Integer.MIN_VALUE;
        Car car=null;
        for(Car car1:data){
            if(car1.getYear()>oldest){
                car=car1;
            }
        }
        return car;

         */
         Car result=null;
         for(Car car:data){
             if(result==null || result.getYear()<car.getYear()){
                 result=car;
             }
         }
         return result;
    }
    public Car getCar(String manufacturer, String model){
        Car car=null;
        for(Car car1:data){
            if(car1.getManufacturer().equals(manufacturer)&&car1.getModel().equals(model)){
                car=car1;
            }
        }
        return car;
    }
    public int getCount(){
        return data.size();
    }
    public String getStatistics(){
        StringBuilder sb=new StringBuilder();
        sb.append(String.format("The cars are parked in %s:%n",this.type));
        for(Car car:data){
            sb.append(car.toString()).append(System.lineSeparator());
        }
        return sb.toString().trim();
    }


}
