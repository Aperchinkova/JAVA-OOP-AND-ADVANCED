package catHouse.entities.houses;

import catHouse.entities.cat.Cat;
import catHouse.entities.toys.Toy;

import java.util.Collection;

public class ShortHouse extends BaseHouse{
    private static final int CAPACITY=15;

    public ShortHouse(String name) {
        super(name,CAPACITY);
    }

    @Override
    public String getStatistics() {
        return null;
    }

    @Override
    public String getName() {
        return null;
    }

    @Override
    public Collection<Cat> getCats() {
        return null;
    }

    @Override
    public Collection<Toy> getToys() {
        return null;
    }
}
