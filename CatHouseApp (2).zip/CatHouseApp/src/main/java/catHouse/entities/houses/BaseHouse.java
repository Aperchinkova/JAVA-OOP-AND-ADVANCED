package catHouse.entities.houses;

import catHouse.entities.cat.Cat;
import catHouse.entities.toys.Toy;

import java.util.Collection;
import java.util.stream.Collectors;

public abstract class BaseHouse implements House {
    private String name;
    private int capacity;
    private Collection<Toy> toys;
    private Collection<Cat> cats;

    public BaseHouse(String name, int capacity) {
        this.name = name;
        this.capacity = capacity;
    }

    @Override
    public void setName(String name) {
        if(name==null || name.equals(" ")){
            throw new NullPointerException("House name cannot be null or empty.");
        }
        this.name = name;
    }
    @Override
    public int sumSoftness(){
        //Returns the sum of each toy’s softness in the House.
        int sum=0;
        for(Toy t:toys){
            sum+=t.getSoftness();
        }
        return sum;
    }
    @Override
    public void addCat(Cat cat){
        if(capacity>cats.size()){
            cats.add(cat);
        }else{
            throw new IllegalStateException("Not enough capacity for this cat.");
        }
    }
    @Override
    public void removeCat(Cat cat){
        cats.remove(cat);
    }
    @Override
    public void buyToy(Toy toy){
        toys.add(toy);
    }
    @Override
    public void feeding(){
        for (Cat c:cats){
            c.eating();
        }
    }

    @Override
    public String getStatistics(){
        StringBuilder sb=new StringBuilder();
        sb.append(String.format("%s %s:%n",this.getName(),this.getClass().getSimpleName())).append(System.lineSeparator());
        sb.append("Cats: ");
        if(cats.isEmpty()){
            sb.append("none");
        }else{
            sb.append(cats.stream().map(Cat::getName).collect(Collectors.joining(" ")).trim());
        }
        sb.append(String.format("Toys: %d Softness: %d",toys.size(),this.sumSoftness()));
        return sb.toString();
    }

}
