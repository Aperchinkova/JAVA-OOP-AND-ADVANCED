package catHouse.entities.cat;

public abstract class BaseCat implements Cat{
    private String name;
    private String breed;
    private int kilograms;
    private double price;

    public BaseCat(String name, String breed, double price) {
        this.setName(name);
        this.setBreed(breed);
        this.setKilograms(kilograms);
        this.setPrice(price);
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public void setName(String name) {
        if(name==null || name.equals(" ")){
            throw new NullPointerException("Cat name cannot be null or empty.");
        }
        this.name = name;
    }

    @Override
    public int getKilograms() {
        return kilograms;
    }

    @Override
    public double getPrice() {
        return price;
    }

    @Override
    public void eating() {
        //The eating() method increases the Cat’s kilograms.
        // Keep in mind that some breeds of Cat can implement the method differently.
    }

    private String getBreed() {
        return breed;
    }

    private void setBreed(String breed) {
        if(breed==null || breed.equals(" ")){
            throw new NullPointerException("Cat breed cannot be null or empty.");
        }
        this.breed = breed;
    }

    public void setKilograms(int kilograms) {
        this.kilograms = kilograms;
    }

    private void setPrice(double price) {
        if(price<=0){
            throw new IllegalArgumentException("Cat price cannot be below or equal to 0.");
        }
        this.price = price;
    }



}
