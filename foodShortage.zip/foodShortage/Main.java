package foodShortage;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        int n=Integer.parseInt(scanner.nextLine());
        Map<String,Citizen> c=new LinkedHashMap<>();
        Map<String,Rebel> r=new LinkedHashMap<>();
        for(int i=0;i<n;i++){
            String[] input=scanner.nextLine().split("\\s+");
            if(input.length==4){
                Citizen citizen=new Citizen(input[0],Integer.parseInt(input[1]),input[2],input[3]);
                c.put(input[0],citizen);
            }else if(input.length==3){
                Rebel rebel=new Rebel(input[0],Integer.parseInt(input[1]),input[2]);
                r.put(input[0],rebel);
            }
        }
        String names=scanner.nextLine();
        int citizenFood=0;
        int rebelFood=0;
        while (!names.equals("End")){
            /*
            for (String s :c.keySet()){
                if(s.equals(names)){
                    citizenFood+=10;
                }
            }
            for (String s :r.keySet()){
                if(s.equals(names)){
                    rebelFood+=5;
                }
            }

             */
            for(Citizen person:c.values()){
                if(person.getName().equals(names)){
                    person.buyFood();
                }
            }
            for(Rebel person:r.values()){
                if(person.getName().equals(names)){
                    person.buyFood();
                }
            }

            names=scanner.nextLine();
        }
        int total=0;
        for(Citizen person:c.values()){

                total+=person.getFood();

        }
        for(Rebel person:r.values()){
                total+=person.getFood();

        }
        System.out.println(total);
    }
}
