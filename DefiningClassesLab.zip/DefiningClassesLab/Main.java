package DefiningClassesLab;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
       // Car car=new Car();
        /*
        car.setBrand("Chevrolet");
        car.setModel("Impala");
        car.setHorsePower(390);

         */
       // System.out.println(String.format("The car is: %s %s - %d HP",car.getBrand(),car.getModel(),car.getHorsePower()));
        int n=Integer.parseInt(scanner.nextLine());
        List<Car> list=new ArrayList<>();
        for(int i=0;i<n;i++)
        {
            String[] input=scanner.nextLine().split("\\s+");
            String brand=input[0];
            String model=input[1];
            int horsePower=Integer.parseInt(input[2]);
            Car car=new Car();
            car.setBrand(brand);
            car.setModel(model);
            car.setHorsePower(horsePower);
            list.add(car);
        }
        //System.out.println(car.carInfo());
        list.forEach(car-> System.out.println(car.carInfo()));
    }
}
