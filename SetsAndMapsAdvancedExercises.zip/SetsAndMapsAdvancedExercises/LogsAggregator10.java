package ADVANCED.SetsAndMapsAdvancedExercises;

import java.util.*;

public class LogsAggregator10 {
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        TreeMap<String,Integer> durations=new TreeMap<>();
        HashMap<String, TreeSet<String>> ips=new HashMap<>();
        int n=Integer.parseInt(scanner.nextLine());
        for(int i=0;i<n;i++)
        {
            String[] input= scanner.nextLine().split("\\s+");
            String ip=input[0];
            String name=input[1];
            int duration=Integer.parseInt(input[2]);

            if(!ips.containsKey(name))//ako v ips go nqma imeto
            {
                ips.put(name,new TreeSet<>(){{add(ip);}});//->slagame mu imeto i sreshtu nego dobavqme Set v koito sme dobavili vuvedenoto ip
                durations.put(name,duration);//v duration map-a slagame imeto i vuvedeniq duration
            }else{//ako go imame imeto v ips(USERNAMES->SET<IPS>)
                TreeSet<String> set = ips.get(name);//vzimame value-to na map-a s ip-tata
                if(set.contains(ip))
                {
                    int updateDuration=durations.get(name)+duration;
                    durations.put(name,updateDuration);
                }else{
                    ips.get(name).add(ip);
                    int updateDuration=durations.get(name)+duration;
                    durations.put(name,updateDuration);
                }
            }


        }
        for(Map.Entry<String,Integer> e:durations.entrySet())
        {
            System.out.printf("%s: %d [%s]\n",e.getKey(),e.getValue(),String.join(", ",ips.get(e.getKey())));
        }
    }
}
