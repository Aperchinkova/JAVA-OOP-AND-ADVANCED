package ADVANCED.SetsAndMapsAdvancedExercises;

import java.util.*;

public class UserLogs08 {
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);

        TreeMap<String,LinkedHashMap<String,Integer>> logs=new TreeMap<>();
        String input= scanner.nextLine();
        while(!input.equals("end"))
        {
            String[] parts=input.split("\\s+");
            String ip=parts[0].split("=")[1];
            String userName=parts[2].split("=")[1];
            if(!logs.containsKey(userName))
            {
                LinkedHashMap<String,Integer> map=new LinkedHashMap<>();
                map.put(ip,1);
                logs.put(userName,map);
            }else {
                Map<String, Integer> map = logs.get(userName);
                if (map.containsKey(ip)) {
                    int currentTimes = map.get(ip);
                    map.put(ip, currentTimes + 1);
                } else {
                    map.put(ip, 1);
                }
            }
            input= scanner.nextLine();
        }

        for(var attacker:logs.entrySet())
        {
            System.out.printf("%s:%n",attacker.getKey());
            LinkedHashMap<String,Integer> attacks=attacker.getValue();
            StringBuilder sb=new StringBuilder();
            for(var singleAttack:attacks.entrySet())
            {
                String formattedAttack=String.format("%s => %d, ",singleAttack.getKey(),singleAttack.getValue());
                sb.append(formattedAttack);
            }
            String finalOutput=sb.substring(0,sb.length()-2);
            finalOutput=finalOutput+".";
            System.out.println(finalOutput);

        }
    }
}
