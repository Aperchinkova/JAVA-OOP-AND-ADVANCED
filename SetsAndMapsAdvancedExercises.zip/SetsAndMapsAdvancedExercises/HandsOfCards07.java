package ADVANCED.SetsAndMapsAdvancedExercises;

import java.util.*;

public class HandsOfCards07 {
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);

        Map<String, Set<String>> map=new LinkedHashMap<>();
        String input= scanner.nextLine();
        while(!input.equals("JOKER"))
        {
            String[] parts=input.split(":\\s+");
            String name=parts[0];
            String[] cards=parts[1].split(", ");

            Set<String> card=new HashSet<>();
            card.addAll(Arrays.asList(cards));

            if(!map.containsKey(name))
            {
                map.put(name,card);
            }else{
                Set<String> set = map.get(name);
                set.addAll(card);
                map.put(name,set);
            }
            input= scanner.nextLine();
        }
        map.entrySet().stream().forEach(e->{
            String name=e.getKey();
            Set<String> cards=e.getValue();
            int points=getCardsPoints(cards);
            System.out.printf("%s: %d%n",name,points);
        });
    }

    private static int getCardsPoints(Set<String> cards) {
        int sumPoints=0;
        Map<Character,Integer> symbolValues=getSymbolValues();
        for(String card:cards)
        {

            int points=0;
            if(card.startsWith("10"))
            {
                char type=card.charAt(2);
                points=10*symbolValues.get(type);
            }else{
                char power=card.charAt(0);
                char type=card.charAt(1);
                points=symbolValues.get(power)*symbolValues.get(type);
            }
            sumPoints+=points;
        }
        return sumPoints;
    }

    private static Map<Character, Integer> getSymbolValues() {//suzdavame si edin method koito ni vrushta populnen map
        Map<Character,Integer> charValues=new HashMap<>();
        charValues.put('2',2);
        charValues.put('3',3);
        charValues.put('4',4);
        charValues.put('5',5);
        charValues.put('6',6);
        charValues.put('7',7);
        charValues.put('8',8);
        charValues.put('9',9);
        charValues.put('J',11);
        charValues.put('Q',12);
        charValues.put('K',13);
        charValues.put('A',14);
        charValues.put('S',4);
        charValues.put('H',3);
        charValues.put('D',2);
        charValues.put('C',1);
        return charValues;
    }
}
