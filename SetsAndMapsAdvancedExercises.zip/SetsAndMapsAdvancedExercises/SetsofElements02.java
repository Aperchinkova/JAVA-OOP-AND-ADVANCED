package ADVANCED.SetsAndMapsAdvancedExercises;

import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.Scanner;
import java.util.Set;

public class SetsofElements02 {
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);

        int[] input= Arrays.stream(scanner.nextLine().split(" "))
                .mapToInt(Integer::parseInt).toArray();
        Set<Integer> first=new LinkedHashSet<>();
        Set<Integer> second=new LinkedHashSet<>();
        Set<Integer>third=new LinkedHashSet<>();
        for(int i=0;i<input[0];i++)
        {
            int k=Integer.parseInt(scanner.next());
            first.add(k);
        }
        for(int i=0;i<input[1];i++)
        {
            int k=Integer.parseInt(scanner.next());
            second.add(k);
        }
        for (Integer i:first) {
            if(second.contains(i))
            {
                third.add(i);
            }
        }
        for(Integer k:third)
        {
            System.out.print(k+" ");
        }
    }
}
