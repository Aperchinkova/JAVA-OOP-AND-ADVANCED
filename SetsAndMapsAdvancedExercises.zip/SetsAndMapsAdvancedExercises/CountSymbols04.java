package ADVANCED.SetsAndMapsAdvancedExercises;

import java.util.Arrays;
import java.util.Map;
import java.util.Scanner;
import java.util.TreeMap;

public class CountSymbols04 {
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        String[] input=scanner.nextLine().split("");

        Map<Character,Integer> alpha=new TreeMap<>();
        for (String i:input) {
            for(int k=0;k<i.length();k++)
            {
                char symbol=i.charAt(k);
                if(!alpha.containsKey(symbol)) {
                    alpha.put(symbol, 1);
                }else{
                    Integer integer = alpha.get(symbol);
                    alpha.put(symbol,integer+1);
                }
            }
        }
        alpha.entrySet().stream().forEach(e-> System.out.println(e.getKey()+": "+e.getValue()+" time/s"));
    }
}
