package ADVANCED.SetsAndMapsAdvancedExercises;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.TreeMap;

public class PopulationCounter09 {
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        String input= scanner.nextLine();
        Map<String, LinkedHashMap<String,Long>> data=new LinkedHashMap<>();
        while(!input.equals("report"))
        {
            String[] parts=input.split("\\|");
            String city=parts[0];
            String country=parts[1];
            long population=Long.parseLong(parts[2]);
            /*
            if(!data.containsKey(country))
            {
                data.put(country,new LinkedHashMap<>());
                data.get(country).put(city,population);
            }else{
                LinkedHashMap<String, Long> map = data.get(country);
                map.put(city,population);
                data.put(country,map);
            }

             */
            data.putIfAbsent(country,new LinkedHashMap<>());
            data.get(country).putIfAbsent(city,population);
            input= scanner.nextLine();
        }
        data.entrySet().stream().sorted(
                (c1,c2)->{//shte sortirame obshtoto naselenie na durjavite
                    long p1=c1.getValue()//vzimame Map-a na durjavata
                            .values()//vzimame value-tata na tozi map(vsichkite)
                            .stream().mapToLong(e->e)//streamvame,map-vame kum long
                            .sum();//sumirame vsichki naseleniq na gradovete na tazi durjava
                    long p2=c2.getValue().values().stream().mapToLong(e->e).sum();
                    return Long.compare(p2,p1);//sortirali sme v nizhodqsht red
                }).forEach(c->{
                    long totalPopulation=c.getValue().values().stream().mapToLong(e->e).sum();
                    System.out.println(c.getKey()+" (total population: "+totalPopulation+")");
                    LinkedHashMap<String, Long> cityInfo = c.getValue();
                    cityInfo.entrySet().stream().sorted(
                            (s1,s2)->Long.compare(s2.getValue(),s1.getValue()))
                            .forEach(s-> System.out.println(String.format("=>%s: %d",s.getKey(),s.getValue())));
        });

    }
}
