package ADVANCED.SetsAndMapsAdvancedExercises;

import java.util.LinkedHashSet;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeSet;

public class PeriodicTable03 {
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        int n=Integer.parseInt(scanner.nextLine());
        Set<String> el=new TreeSet<>();
        for(int i=0;i<n;i++)
        {
            String[] input= scanner.nextLine().split("\\s+");
            for(String k:input)
            {
                el.add(k);
            }
        }
        el.forEach(e-> System.out.print(e+" "));

    }
}
