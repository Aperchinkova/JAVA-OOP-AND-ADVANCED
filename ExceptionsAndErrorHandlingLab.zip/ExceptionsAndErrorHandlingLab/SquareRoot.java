package ExceptionsAndErrorHandlingLab;

import java.util.IllegalFormatException;
import java.util.Scanner;

public class SquareRoot {
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);

        try {
            int number=Integer.parseInt(scanner.nextLine());
            double n=Math.sqrt(number);
            System.out.printf("%.2f%n",n);

        }catch (Exception e){
            System.out.println("Invalid");
        }finally {
            System.out.println("Goodbye");
        }

    }

}
