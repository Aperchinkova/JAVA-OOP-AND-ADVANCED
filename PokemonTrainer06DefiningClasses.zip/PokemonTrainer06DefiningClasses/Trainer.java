package ADVANCED.PokemonTrainer06DefiningClasses;

import java.util.*;

public class Trainer {

    private String name;
    private Map<String,List<Pokemon>> pokemons;
    private int badges=0;

    public int getBadges() {
        return badges;
    }

    public Trainer(String name)
    {
        this.name=name;
        this.badges=0;
        this.setPokemons();
    }

    private void setPokemons()
    {
       // Map<String,List<Pokemon>> pokemons=new LinkedHashMap<>();
        this.pokemons=new HashMap<>();
        pokemons.put("Fire",new ArrayList<>());
        pokemons.put("Water",new ArrayList<>());
        pokemons.put("Electricity",new ArrayList<>());
    }


    public void addPokemons(Pokemon pokemon) {
        this.pokemons.putIfAbsent(pokemon.getElement(),new ArrayList<>());
        this.pokemons.get(pokemon.getElement()).add(pokemon);//
        //this.pokemons-samiqt map s elementite(key)->list(value)with elements
        //get-vame mu na toq list elementa na dadeniqt ni pokemon i taka sme poluchili key -> value + pokemon

    }

    public boolean hasElement(String element) {
        return this.pokemons.get(element).size()!=0;
    }

    public void incrementBadge(int increment) {
        this.badges+=increment;
    }

    public void decrementHealth(int decrement) {
        for(List<Pokemon> list: pokemons.values())
        {
            for(Pokemon pokemon:list)
            {
                pokemon.decreaseHealth(decrement);
            }
        }
        clearDeadPokemons();
    }
    public void clearDeadPokemons()
    {
        for(List<Pokemon> list:pokemons.values())
        {
            list.removeIf(p->p.getHealth()<=0);
        }
    }
    public int getPokemonsCount()
    {
        int sum=0;
        for(List<Pokemon> list:pokemons.values())
        {
            sum+= list.size();
        }
        return sum;
    }
    @Override
    public String toString()
    {
        return String.format("%s %d %d",this.name,this.badges,this.getPokemonsCount());
    }
}
