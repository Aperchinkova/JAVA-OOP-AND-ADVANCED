package ADVANCED.StreamsFilesAndDirectoriesExercises;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

public class SumBytes02 {
    public static void main(String[] args) throws IOException {
        String path="C:\\Users\\LENOVO\\Documents\\04. Java-Advanced-Files-and-Streams-Exercises-Resources//input.txt";
        BufferedReader bufferedReader=new BufferedReader(new FileReader(path));
        long sum=0;
        /*
        String line= bufferedReader.readLine();
        while (line!=null)
        {
            for (int index=0;index<line.length();index++)
            {
                char symbol=line.charAt(index);
                sum+=symbol;
            }
            line= bufferedReader.readLine();
        }

         */
        byte[] bytes= Files.readAllBytes(Path.of(path));
        for(byte b:bytes)
        {
            if(b!=10 && b!=13)
            {
                sum+=b;
            }
        }
        System.out.println(sum);
    }
}
