package ADVANCED.StreamsFilesAndDirectoriesExercises;

import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class WordCount06 {
    public static void main(String[] args) throws IOException {
        String words="C:\\Users\\LENOVO\\Documents\\04. Java-Advanced-Files-and-Streams-Exercises-Resources\\words.txt";
        Map<String,Integer> wordsCount=new HashMap<>();
        List<String> allLines= Files.readAllLines(Path.of(words));
        for(String s:allLines)
        {
            Arrays.stream(s.split("\\s+")).forEach(e-> wordsCount.put(e,0));
        }
        String file="C:\\Users\\LENOVO\\Documents\\04. Java-Advanced-Files-and-Streams-Exercises-Resources\\text.txt";
        List<String> textLines=Files.readAllLines(Path.of(file));
        for(String line:textLines)
        {
            Arrays.stream(line.split("\\s+")).forEach(word-> {
                if (wordsCount.containsKey(word)) {
                    int current = wordsCount.get(word);
                    wordsCount.put(word, current + 1);
                }
            });
        }
        PrintWriter writer=new PrintWriter("results.txt");
        wordsCount.entrySet().stream().sorted((e1,e2)-> e2.getValue().compareTo(e1.getValue()))
                .forEach(entry->writer.println(entry.getKey()+" - "+entry.getValue()));
        writer.close();
    }
}
