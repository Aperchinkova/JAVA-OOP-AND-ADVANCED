package ADVANCED.StreamsFilesAndDirectoriesExercises;

import java.io.File;

public class GetFolderSize08 {
    public static void main(String[] args) {
        String path="C:\\Users\\LENOVO\\Documents\\04. Java-Advanced-Files-and-Streams-Exercises-Resources//Exercises Resources";
        File file=new File(path);
        File[] files=file.listFiles();
        int folderSize=0;
        for (File f:files)
        {
            folderSize+=f.length();
        }
        System.out.println("Folder size: "+folderSize);

    }
}
