package ADVANCED.StreamsFilesAndDirectoriesExercises;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

public class CountCharacterTypes04 {
    public static void main(String[] args) throws IOException {
        String pathIn = "D:\\Softuni Java\\Java Advanced\\04. Java-Advanced-Files-and-Streams-Exercises-Resources\\input.txt";
        String pathOut = "output1.txt";
        List<String> lines = Files.readAllLines(Path.of(pathIn));
        int sumVowels = 0;
        int sumConsonants = 0;
        int sumPunct = 0;

        for (String line:lines) {
            int vowels = vowelsByLine(line);
            sumVowels += vowels;
            int consonants = consonantsByLine(line);
            sumConsonants+=consonants;
            int puncts = punctuationByLine(line);
            sumPunct +=puncts;
        }

        PrintWriter writer = new PrintWriter(pathOut);
        writer.println("Vowels: "+sumVowels);
        writer.println("Consonants: "+sumConsonants);
        writer.println("Punctuation: "+sumPunct);
        writer.close();

    }

    private static int punctuationByLine(String line) {
        int punct = 0;
        for (int i = 0; i < line.length(); i++) {
            char currentChar = line.charAt(i);
            if(currentChar=='!'|| currentChar==','|| currentChar=='.'|| currentChar=='?'){
                punct++;
            }
        }
        return punct;
    }

    private static int consonantsByLine(String line) {
        int consonants = 0;
        for (int i = 0; i < line.length(); i++) {
            char currentSymbol = line.charAt(i);
            if(     currentSymbol!='a'&&
                    currentSymbol!='e'&&
                    currentSymbol!='i'&&
                    currentSymbol!='o'&&
                    currentSymbol!='u'&&
                    currentSymbol!='!'&&
                    currentSymbol!=','&&
                    currentSymbol!='.'&&
                    currentSymbol!='?'&&
                    currentSymbol!=' '){
                consonants++;
            }
        }
        return consonants;
    }

    private static int vowelsByLine(String line) {
        int vowels = 0;
        for (int i = 0; i < line.length(); i++) {
            char currentSymbol = line.charAt(i);
            if(currentSymbol=='a'|| currentSymbol=='e'|| currentSymbol=='i'|| currentSymbol=='o'|| currentSymbol=='u'){
                vowels++;
            }
        }
        return vowels;
    }
}
