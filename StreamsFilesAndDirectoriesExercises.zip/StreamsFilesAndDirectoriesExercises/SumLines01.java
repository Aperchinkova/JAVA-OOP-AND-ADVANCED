package ADVANCED.StreamsFilesAndDirectoriesExercises;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

public class SumLines01 {
    public static void main(String[] args) throws IOException {
        String path="C:\\Users\\LENOVO\\Documents\\04. Java-Advanced-Files-and-Streams-Exercises-Resources//input.txt";
     //1.way
       // List<String> allLines= Files.readAllLines(Path.of(path));
        /*
        for(String line:allLines)
        {
            int sum=0;
            for(int index=0;index<line.length();index++)
            {
                char symbol=line.charAt(index);
                sum+=symbol;
            }
            System.out.println(sum);
        }

         */
        /*
        allLines.stream()
                .map(line-> line.toCharArray())
                .forEach(arr->{
                    int sum=0;
                    for(char symbol:arr)
                    {
                        sum+=symbol;
                    }
                    System.out.println(sum);
                        });
        ;

         */
        //2.way
        try{
            BufferedReader reader=Files.newBufferedReader(Paths.get(path));
            String line=reader.readLine();
            PrintStream printStream=new PrintStream("char-sum-line.txt");
            while (line!=null)
            {
                int sum=0;
                for(char symbol:line.toCharArray())
                {
                    sum+=symbol;
                }
                printStream.println(sum);
                line= reader.readLine();
            }
        }catch (IOException exception)
        {
            System.out.println(exception.getMessage());
        }

    }
}
