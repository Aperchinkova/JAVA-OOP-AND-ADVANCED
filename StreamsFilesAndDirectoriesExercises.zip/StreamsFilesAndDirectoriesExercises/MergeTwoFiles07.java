package ADVANCED.StreamsFilesAndDirectoriesExercises;

import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

public class MergeTwoFiles07 {
    public static void main(String[] args) throws IOException {
        String first="C:\\Users\\LENOVO\\Documents\\04. Java-Advanced-Files-and-Streams-Exercises-Resources//inputOne.txt";
        String second="C:\\Users\\LENOVO\\Documents\\04. Java-Advanced-Files-and-Streams-Exercises-Resources//inputTwo.txt";
        List<String> l= Files.readAllLines(Path.of(first));
        PrintWriter pw=new PrintWriter("outputTwo.txt");
        l.forEach(line->pw.println(line));
        List<String> s=Files.readAllLines(Path.of(second));
        s.forEach(line->pw.println(line));
        pw.close();
    }
}
