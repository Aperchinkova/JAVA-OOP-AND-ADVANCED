package ADVANCED.StreamsFilesAndDirectoriesExercises;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

public class ALLCAPITALS03 {
    public static void main(String[] args) throws IOException {
        String path="C:\\Users\\LENOVO\\Documents\\04. Java-Advanced-Files-and-Streams-Exercises-Resources//input.txt";

        BufferedWriter bw=new BufferedWriter(new FileWriter("output.txt"));
        /*
        List<String> allLines= Files.readAllLines(Path.of(path));
        for (String line:allLines)
        {
            bw.write(line.toUpperCase());
            bw.newLine();
        }
        bw.close();

         */
        BufferedReader reader=new BufferedReader(new FileReader(path));
        String line= reader.readLine();
        while(line!=null)
        {
            bw.write(line.toUpperCase());
            bw.newLine();
            line= reader.readLine();
        }
        bw.close();
    }
}
