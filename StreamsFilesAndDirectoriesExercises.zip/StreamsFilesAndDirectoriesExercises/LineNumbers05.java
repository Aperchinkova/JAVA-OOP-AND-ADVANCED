package ADVANCED.StreamsFilesAndDirectoriesExercises;

import javax.sound.sampled.Line;
import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

public class LineNumbers05 {
    public static void main(String[] args) throws IOException {
        String input="C:\\Users\\LENOVO\\Documents\\04. Java-Advanced-Files-and-Streams-Exercises-Resources\\inputLineNumbers.txt";
        List<String> allLines= Files.readAllLines(Path.of(input));
        //BufferedWriter bw=new BufferedWriter(new FileWriter("output_line_numbers.txt"));
        PrintWriter bw=new PrintWriter("output_line_numbers.txt");
        int count=1;
        for(String s:allLines)
        {
            /*
            bw.write(count+". "+s);
            bw.newLine();

             */
            bw.println(count+". "+s);
            count++;
        }
        bw.close();
    }
}
