package christmasPastryShop.core;

import christmasPastryShop.common.ExceptionMessages;
import christmasPastryShop.common.OutputMessages;
import christmasPastryShop.core.interfaces.Controller;
import christmasPastryShop.entities.booths.OpenBooth;
import christmasPastryShop.entities.booths.PrivateBooth;
import christmasPastryShop.entities.cocktails.Hibernation;
import christmasPastryShop.entities.cocktails.MulledWine;
import christmasPastryShop.entities.delicacies.Gingerbread;
import christmasPastryShop.entities.delicacies.Stolen;
import christmasPastryShop.entities.delicacies.interfaces.Delicacy;
import christmasPastryShop.entities.cocktails.interfaces.Cocktail;
import christmasPastryShop.entities.booths.interfaces.Booth;
import christmasPastryShop.repositories.BoothRepositoryImpl;
import christmasPastryShop.repositories.CocktailRepositoryImpl;
import christmasPastryShop.repositories.DelicacyRepositoryImpl;
import christmasPastryShop.repositories.interfaces.BoothRepository;
import christmasPastryShop.repositories.interfaces.CocktailRepository;
import christmasPastryShop.repositories.interfaces.DelicacyRepository;

import java.util.Collection;

public class ControllerImpl implements Controller {
    private final BoothRepository<Booth> boothRepository;
    private final CocktailRepository<Cocktail> cocktailRepository;
    private final DelicacyRepository<Delicacy> delicacyRepository;
    private double totalStoreIncome;

    public ControllerImpl(DelicacyRepository<Delicacy> delicacyRepository, CocktailRepository<Cocktail> cocktailRepository, BoothRepository<Booth> boothRepository) {
        this.delicacyRepository=new DelicacyRepositoryImpl();
        this.cocktailRepository=new CocktailRepositoryImpl();
        this.boothRepository=new BoothRepositoryImpl();
        this.totalStoreIncome=0;
    }


    @Override
    public String addDelicacy(String type, String name, double price) {
        // TODO
        //Creates a delicacy with the correct type. If the delicacy is created successfully, returns:
        //"Added delicacy {delicacy name} - {delicacy type} to the pastry shop!"

        Delicacy delicacy=delicacyRepository.getByName(name);
        if(delicacy!=null){
            throw new IllegalArgumentException(String.format(ExceptionMessages.FOOD_OR_DRINK_EXIST,type,name));
        }
        switch (type){
            case"Gingerbread":
                delicacy = new Gingerbread(name,price);
                this.delicacyRepository.add(delicacy);
                break;
            case "Stolen":
                delicacy = new Stolen(name,price);
                this.delicacyRepository.add(delicacy);
                break;
        }

        return String.format(OutputMessages.DELICACY_ADDED,name,type);
    }

    @Override
    public String addCocktail(String type, String name, int size, String brand) {

        //If a cocktail with the given name already exists in the cocktail repository,
        // throw an IllegalArgumentException with the message "{type} {name} is already in the pastry shop!"

        Cocktail cocktail=cocktailRepository.getByName(name);
        if(cocktail!=null){
            throw  new IllegalArgumentException(String.format(ExceptionMessages.FOOD_OR_DRINK_EXIST,name,brand));
        }
        switch (type){
            case"Hibernation":
                cocktail = new Hibernation(name,size,brand);
                this.cocktailRepository.add(cocktail);
                break;
            case "MulledWine":
                cocktail = new MulledWine(name,size,brand);
                this.cocktailRepository.add(cocktail);
                break;
        }
        return String.format(OutputMessages.COCKTAIL_ADDED,name,brand);

    }

    @Override
    public String addBooth(String type, int boothNumber, int capacity) {
        Booth booth= boothRepository.getByNumber(boothNumber);
        if(booth != null){
            throw new IllegalArgumentException(String.format(ExceptionMessages.BOOTH_EXIST,boothNumber));
        }
        switch (type){
            case "OpenBooth":
                booth = new OpenBooth(boothNumber,capacity);
                this.boothRepository.add(booth);
                break;
            case "PrivateBooth":
                booth = new PrivateBooth(boothNumber,capacity);
                this.boothRepository.add(booth);
                break;
        }
        return String.format(OutputMessages.BOOTH_ADDED,boothNumber);
    }

    @Override
    public String reserveBooth(int numberOfPeople) {
        //Finds a booth that is not reserved, and its capacity is enough for the number of people provided.
        // If there is no such booth returns:
        //"No available booth for {numberOfPeople} people!"
        //In the other case reserves the booth and return:
        //"Booth {boothNumber} has been reserved for {numberOfPeople} people!"
        Collection<Booth> booths=boothRepository.getAll();
        Booth booth=booths.stream().filter(e->!e.isReserved() && e.getCapacity()>=numberOfPeople).findFirst().orElse(null);
        if(booth!=null){
            booth.reserve(numberOfPeople);
            return String.format(OutputMessages.BOOTH_RESERVED,booth.getBoothNumber(),numberOfPeople);
        }
        return String.format(OutputMessages.RESERVATION_NOT_POSSIBLE,numberOfPeople);
    }

    @Override
    public String leaveBooth(int boothNumber) {

        // The bill is not only the orders, but the reservation for the number of people as well. Finally returns:
        //"Booth: {boothNumber}"
        //"Bill: {booth bill:f2}"
        Booth booth=this. boothRepository.getByNumber(boothNumber);
        double bill=booth.getBill();
        booth.clear();
        totalStoreIncome+=bill;

        return String.format(OutputMessages.BILL,boothNumber,bill);
    }

    @Override
    public String getIncome() {
        //Returns the total income for the pastry shop for all completed bills.
        //"Income: {income:f2}lv"
        return String.format(OutputMessages.TOTAL_INCOME,totalStoreIncome);
    }
}
