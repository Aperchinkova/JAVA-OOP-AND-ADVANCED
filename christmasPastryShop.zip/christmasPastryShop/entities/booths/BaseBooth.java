package christmasPastryShop.entities.booths;

import christmasPastryShop.common.ExceptionMessages;
import christmasPastryShop.entities.booths.interfaces.Booth;
import christmasPastryShop.entities.cocktails.interfaces.Cocktail;
import christmasPastryShop.entities.delicacies.interfaces.Delicacy;
import java.util.ArrayList;
import java.util.Collection;

public abstract class BaseBooth implements Booth {
    private Collection<Delicacy> delicacyOrders;
    private Collection<Cocktail> 	cocktailOrders;
    private int boothNumber;
    private int capacity;
    private int numberOfPeople;//the count of people who want a booth.
    private double pricePerPerson;//the price per person for the booth.
    private boolean isReserved;//returns true if the booth is reserved, otherwise false.
    private double price;//calculates the price for all people.

    public BaseBooth(int boothNumber, int capacity, double pricePerPerson) {
        this.boothNumber = boothNumber;
        this.setCapacity(capacity);
        this.pricePerPerson = pricePerPerson;
        this.delicacyOrders=new ArrayList<>();
        this.cocktailOrders=new ArrayList<>();
    }
    /*
    private void setNumberOfPeople(int numberOfPeople) {
        if(numberOfPeople<=0){
            throw new IllegalArgumentException(ExceptionMessages.INVALID_NUMBER_OF_PEOPLE);
        }
        this.numberOfPeople = numberOfPeople;
    }


     */
    private void setCapacity(int capacity) {
        if(capacity<0){
            throw new IllegalArgumentException(ExceptionMessages.INVALID_TABLE_CAPACITY);
        }
        this.capacity = capacity;
    }

    @Override
    public int getBoothNumber() {
        return boothNumber;
    }

    @Override
    public int getCapacity() {
        return capacity;
    }

    @Override
    public boolean isReserved() {
        return isReserved;
    }

    @Override
    public double getPrice() {
        return price;
    }

    @Override
    public void reserve(int numberOfPeople) {
        //Reserve the booth with the count of people given and calculate the price of the booth.
        if(numberOfPeople<=0){
            throw new IllegalArgumentException(ExceptionMessages.INVALID_NUMBER_OF_PEOPLE);
        }
        this.numberOfPeople=numberOfPeople;
        this.isReserved=true;
        this.price=pricePerPerson*numberOfPeople;
    }

    @Override
    public double getBill() {
        double del=delicacyOrders.stream().mapToDouble(Delicacy::getPrice).sum();
        double coc=cocktailOrders.stream().mapToDouble(Cocktail::getPrice).sum();
        return del+coc+(numberOfPeople*pricePerPerson);
    }

    @Override
    public void clear() {
        //Removes all the ordered cocktails and delicacies and
        // finally frees the booth, sets the count of people and price to 0.

        cocktailOrders.clear();
        delicacyOrders.clear();
        this.isReserved=false;
        this.numberOfPeople=0;
        this.price=0;
    }
}
