package firstZad;

public class Test {
    public static void main(String[] args) {
        Teacher teacher=new Teacher("Dean","Dimo","Java","Biology","Math");
        System.out.println(teacher.toString());
    }
}
