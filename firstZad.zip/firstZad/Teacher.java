package firstZad;

public class Teacher extends Person{
    private String courseName;
    private String biology;
    private String math;

    public Teacher(String name,String lastName ,String courseName,String biology,String math) {
        super(lastName, name);
        this.courseName=courseName;
        this.biology=biology;
        this.math=math;
    }

    public String getCourseName() {
        return courseName;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }

    public String getBiology() {
        return biology;
    }

    public void setBiology(String biology) {
        this.biology = biology;
    }

    public String getMath() {
        return math;
    }

    public void setMath(String math) {
        this.math = math;
    }

    @Override
    public String toString() {
        return String.format("I am %s %s.My course is %s.The main subjects in it are %s and %s.",getName(),getLastName(),courseName,biology,math);
    }
}
