package firstZad;

public class Person {
    private String name;
    private String lastName;

    public Person(String EGN,String name) {
        this.lastName = EGN;
        this.name=name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

}
