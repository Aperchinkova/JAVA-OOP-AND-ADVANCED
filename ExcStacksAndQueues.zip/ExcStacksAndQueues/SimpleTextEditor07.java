package ADVANCED.ExcStacksAndQueues;

import java.util.ArrayDeque;
import java.util.Scanner;

public class SimpleTextEditor07 {
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        StringBuilder text=new StringBuilder();
        int n=Integer.parseInt(scanner.nextLine());
        ArrayDeque<String> stack=new ArrayDeque<>();
        for (int i=0;i<n;i++)
        {
            String[] input= scanner.nextLine().split("\\s+");
            int command=Integer.parseInt(input[0]);
            switch (command)
            {
                case 1:
                    stack.push(text.toString());
                    String string=input[1];
                    text.append(string);
                    break;
                case 2:
                    stack.push(text.toString());
                    int count=Integer.parseInt(input[1]);
                    int startIndexForDelete=text.length()-count;
                    text.delete(startIndexForDelete,startIndexForDelete+count);
                    break;
                case 3:
                    int index=Integer.parseInt(input[1]);
                    System.out.println(text.charAt(index-1));
                    break;
                case 4:
                    if(!stack.isEmpty())
                    {
                        text=new StringBuilder(stack.pop());
                    }
                    break;

            }
        }
    }
}
