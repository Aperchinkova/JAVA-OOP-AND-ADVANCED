package ADVANCED.ExcStacksAndQueues;

import java.util.ArrayDeque;
import java.util.Scanner;

public class BalancedParentheses05 {
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        String input=scanner.nextLine();
        ArrayDeque<Character> brackets=new ArrayDeque<>();
        boolean areBalanced=false;
        for(int i=0;i<=input.length()-1;i++)
        {
            char symbol=input.charAt(i);
            if(symbol=='(' || symbol=='{' || symbol=='['){
                brackets.push(symbol);
            }else if(symbol==')'||symbol=='}'||symbol==']')
            {
                if(brackets.isEmpty())
                {
                    areBalanced=false;
                    break;
                }
                char lastopen=brackets.pop();

                if(symbol =='}' && lastopen=='{')
                {
                    areBalanced=true;
                }else if(symbol ==')' && lastopen=='('){

                    areBalanced=true;
                }else if(symbol ==']' && lastopen=='[')
                {
                    areBalanced=true;
                }else{
                    areBalanced=false;
                    break;
                }
            }
        }
        if(areBalanced){
            System.out.println("YES");
        }else{
            System.out.println("NO");
        }
    }
}
