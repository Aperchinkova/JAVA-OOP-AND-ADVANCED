package ADVANCED.ExcStacksAndQueues;

import java.util.ArrayDeque;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class InfixtoPostfix2 {
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        String[] input=scanner.nextLine().split(" ");
        ArrayDeque<String> operators=new ArrayDeque<>();//stack
        ArrayDeque<String> expression=new ArrayDeque<>();//queue
        Map<String,Integer> priorites=new HashMap<>();
        priorites.put("*",3);
        priorites.put("/",3);
        priorites.put("+",2);
        priorites.put("-",2);
        priorites.put("(",1);
        for (String s: input)
        {
            try{
                double num=Double.parseDouble(s);
                expression.addLast(s);
            }catch(Exception e)
            {
                switch (s)
                {
                    case "x":
                        expression.addLast(s);
                        break;
                    case "(":
                        operators.push(s);
                        break;
                    case ")":
                        String symbol=operators.pop();
                        while(!symbol.equals("("))
                        {
                            expression.addLast(symbol);
                            symbol=operators.pop();
                        }
                        break;
                    default:
                        while(!operators.isEmpty() && priorites.get(operators.peek()) >= priorites.get(s))
                        {
                            expression.addLast(operators.pop());
                        }
                        operators.push(s);
                        break;
                }
            }
        }
        while (!operators.isEmpty())
        {
            expression.addLast(operators.pop());
        }
        while (expression.size()>0)
        {
            System.out.print(expression.pop()+" ");
        }
    }
}
