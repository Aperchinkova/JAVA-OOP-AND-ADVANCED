package ADVANCED.ExcStacksAndQueues;

import java.lang.reflect.Array;
import java.util.ArrayDeque;
import java.util.Arrays;
import java.util.Scanner;

public class InfixtoPostfix08 {
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        String expression=scanner.nextLine();
        String[] tokens=expression.split(" ");
        char[] ch=expression.toCharArray();
        ArrayDeque<Character> queue=new ArrayDeque<>();//operands
        ArrayDeque<Character> stack=new ArrayDeque<>();
        for(int i=0;i<=ch.length-1;i++)
        {
            char symbol= ch[i];

            if(symbol>=48 && symbol<=57){
                queue.offer(symbol);
            }else if(symbol>=97 && symbol<=122)
            {
                queue.offer(symbol);
            }else if(symbol=='+' || symbol=='-' || symbol==47 || symbol=='*'){
                stack.push(symbol);
            }
        }
        for (Character c:queue) {
            System.out.print(c+" ");
        }
        for (Character s:stack) {
            System.out.print(s+" ");
        }

    }
}
