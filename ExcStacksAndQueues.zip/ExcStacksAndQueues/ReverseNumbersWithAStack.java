package ADVANCED.ExcStacksAndQueues;

import java.util.ArrayDeque;
import java.util.Scanner;

public class ReverseNumbersWithAStack {
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        String input= scanner.nextLine();
        String[] numbers=input.split("\\s+");
        ArrayDeque<String> numbs=new ArrayDeque<>();
        /*
        for(int i=0;i<numbers.length;i++)
        {
            numbs.push(numbers[i]);
        }
        for (String s:numbs)
        {
            System.out.print(s+" ");
        }

         */
        for (String s:numbers){
            numbs.push(s);
        }
        while(!numbs.isEmpty())
        {
            System.out.println(numbs.pop()+" ");
        }
    }
}
