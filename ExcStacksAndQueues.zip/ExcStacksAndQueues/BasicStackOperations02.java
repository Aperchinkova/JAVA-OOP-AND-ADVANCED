package ADVANCED.ExcStacksAndQueues;

import java.util.ArrayDeque;
import java.util.Collections;
import java.util.Scanner;

public class BasicStackOperations02 {
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        //String[] input=scanner.nextLine().split("\\s+");
        int n=scanner.nextInt();//push
        int s=scanner.nextInt();//pop
        int x=scanner.nextInt();//check
        ArrayDeque<Integer> stack=new ArrayDeque<>();
        for(int i=0;i<n;i++)
        {
            stack.push(scanner.nextInt());
        }
        for(int j=0;j<s;j++)
        {
            stack.pop();
        }
        if(stack.contains(x))
        {
            System.out.println("true");
        }else{
            if(!stack.isEmpty())
            {
                System.out.println(Collections.min(stack));
            }else{
                System.out.println(0);
            }
        }
    }
}
