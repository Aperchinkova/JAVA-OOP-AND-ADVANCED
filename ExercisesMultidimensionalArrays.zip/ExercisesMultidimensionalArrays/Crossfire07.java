package ADVANCED.ExercisesMultidimensionalArrays;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class Crossfire07 {
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        int[] dimensions= Arrays.stream(scanner.nextLine().split(" ")).mapToInt(Integer::parseInt).toArray();
        int rows=dimensions[0];
        int cols=dimensions[1];
        List<List<Integer>> matrix=new ArrayList<>();
        fill(matrix,rows,cols);


        String command= scanner.nextLine();

        while (!command.equals("Nuke it from orbit"))
        {
            String[] tokens=command.split("\\s+");
            int row = Integer.parseInt(tokens[0]);
            int col = Integer.parseInt(tokens[1]); //индексът на елемента в листа
            int radius = Integer.parseInt(tokens[2]);

            //destroy up,down
            for(int currentRow=row-radius;currentRow<=row+radius;currentRow++)//suotvetniqt red ot koito zapochvame da mahave(ot nego zapochvame)
            {
                if(isInMatrix(matrix,currentRow,col))//currentRow is updating and we are checking if it is valid in thr isInMatrixMethod
                {
                    matrix.get(currentRow).set(col,0);//vzimame updatenatiw red i set-vame na sutvetnata kolona 0
                }
            }
            //destroy left->right
            for(int currentCol=col-radius;currentCol<=col+radius;currentCol++)
            {
                if (isInMatrix(matrix,row,currentCol))
                {
                    matrix.get(row).set(currentCol,0);
                }
            }
            for(int i=0;i<matrix.size();i++)
            {
                matrix.get(i).removeAll(new ArrayList<Integer>(){{add(0);}});
                if(matrix.get(i).size()==0)
                {
                    matrix.remove(i);
                    i--;
                }
            }
            command= scanner.nextLine();
        }
        print(matrix);
    }
    private static void fill(List<List<Integer>> matrix,int row,int col)
    {
        int number=1;
        for(int r=0;r<row;r++)//imame prazen list,obhojdame redovete mu
        {
            //matrix.add(new ArrayList<>());//kato zapochnem ot red -> mu slagame list(list v reda na lista)
            List<Integer> numbers=new ArrayList<>();
            for(int c=0;c<col;c++)//veche imame list v reda na lista i obhojdame colonite mu
            {
                numbers.add(number++);//vzimame list i sme na suotvetnata kolona, i na suotvetniqt red i kolona slagame chisloyo
            }
            matrix.add(numbers);
        }
    }
    private static void print(List<List<Integer>> matrix)
    {
        for (int row=0;row<matrix.size();row++)
        {
            for(int col=0;col<matrix.get(row).size();col++)
            {
                System.out.print(matrix.get(row).get(col)+" ");
            }
            System.out.println();
        }
    }
    private static boolean isInMatrix(List<List<Integer>> matrix,int row,int col)
    {
       return row>=0 && row<matrix.size() && col>=0 && col<matrix.get(row).size();
    }
}
