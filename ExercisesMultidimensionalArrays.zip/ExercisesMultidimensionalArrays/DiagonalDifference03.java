package ADVANCED.ExercisesMultidimensionalArrays;

import java.util.Scanner;

public class DiagonalDifference03 {
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        int n=Integer.parseInt(scanner.nextLine());
        int[][] matrix=new int[n][n];
        fill(matrix,scanner);
        int primary=getPrimaryDiagonalSum(matrix);
        int secondary=getSecondaryDiagonalSum(matrix);
        System.out.println(Math.abs(primary-secondary));
    }
    private static void fill(int[][] matrix,Scanner scanner)
    {
        for(int row=0;row<matrix.length;row++)
        {
            for(int col=0;col<matrix.length;col++)
            {
                matrix[row][col]= scanner.nextInt();
            }
        }
    }
    private static int getPrimaryDiagonalSum(int[][] matrix)
    {
        int sumPrimary=0;
        for(int row=0;row<matrix.length;row++)
        {
            for(int col=0;col<matrix.length;col++)
            {
                if(row==col)
                {
                    sumPrimary+=matrix[row][col];
                }
            }
        }
        return sumPrimary;
    }
    private static int getSecondaryDiagonalSum(int[][] matrix)
    {
        int sumSecondary=0;
        for(int row=0;row<matrix.length;row++)
        {
            for(int col=0;col<matrix.length;col++)
            {
                if(col==matrix.length-row-1)
                {
                    sumSecondary+=matrix[row][col];
                }
            }
        }
        return sumSecondary;
    }
}
