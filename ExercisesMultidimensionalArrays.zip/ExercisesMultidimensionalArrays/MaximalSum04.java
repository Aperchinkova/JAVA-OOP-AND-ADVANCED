package ADVANCED.ExercisesMultidimensionalArrays;

import java.util.Arrays;
import java.util.Scanner;

public class MaximalSum04 {
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        int[] size=Arrays.stream(scanner.nextLine().split(" ")).mapToInt(Integer::parseInt).toArray();
        int row=size[0];
        int col=size[1];

        int[][] matrix=new int[row][col];

        for(int r=0;r<row;r++)
        {
                int[] singleLine=Arrays.stream(scanner.nextLine().split(" ")).mapToInt(Integer::parseInt).toArray();
                matrix[r]=singleLine;
        }

        int bestStartingRow=-1;

        int bestStartingCol=-1;

        int maxSum=Integer.MIN_VALUE;

        for(int r=0;r<row-2;r++)//poslednite 2 reda ne gi obhojdame
        {
            for(int c=0;c<col-2;c++)//poslednite 2 koloni ne gi obhojdame
            {
                int sum=matrix[r][c]+matrix[r][c+1]+matrix[r][c+2]
                        +matrix[r+1][c]+matrix[r+1][c+1]+matrix[r+1][c+2]
                        +matrix[r+2][c]+matrix[r+2][c+1]+matrix[r+2][c+2];
                if(sum>maxSum)
                {
                    maxSum=sum;
                    bestStartingRow=r;
                    bestStartingCol=c;
                }
            }
        }
        System.out.printf("Sum = %d%n",maxSum);
        for(int r=bestStartingRow;r<bestStartingRow+3;r++)//obhojdame ot bestRow do bestRow+3
        {
            for(int c=bestStartingCol;c<bestStartingCol+3;c++)//obhojdame ot bestCol do bestCol+3
            {
                System.out.print(matrix[r][c]+" ");
            }
            System.out.println();
        }
    }

}
