package ADVANCED.ExercisesMultidimensionalArrays;

import java.util.Scanner;

public class FilltheMatrix01 {
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        String[] input=scanner.nextLine().split(", ");
        int n =Integer.parseInt(input[0]);
        String way=input[1];
        int[][] matrix=new int[n][n];
        if(way.equals("A"))
        {
            int[][] a=matrixA(n,n);
            for(int r=0;r<n;r++)
            {
                for(int c=0;c<n;c++)
                {
                    System.out.print(a[r][c]+" ");
                }
                System.out.println();
            }
        }
        else if(way.equals("B"))
        {
            int[][] b=matrixB(n,n);
            for(int r=0;r<n;r++)
            {
                for(int c=0;c<n;c++)
                {
                    System.out.print(b[r][c]+" ");
                }
                System.out.println();
            }
        }


    }
    private static int[][] matrixA(int row,int col)
    {
        int startNumber=1;
        int[][] matrix=new int[row][col];
        for(int c=0;c<col;c++)
        {
            for(int r=0;r<row;r++)
            {
                matrix[r][c]=startNumber;
                startNumber++;
            }

        }
        return matrix;
    }
    private static int[][] matrixB(int row,int col)
    {
        int startNumber=1;
        int[][] matrix=new int[row][col];
        for(int c=0;c<row;c++)
        {
            if(c%2!=0)
            {
                for(int r=row-1;r>=0;r--)
                {
                    matrix[r][c]=startNumber;
                    startNumber++;
                }

            }else{
                for(int r=0;r<row;r++)
                {
                    matrix[r][c]=startNumber;
                    startNumber++;
                }
            }

        }
        return matrix;
    }
}
