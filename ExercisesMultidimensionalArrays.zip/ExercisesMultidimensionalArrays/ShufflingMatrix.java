package ADVANCED.ExercisesMultidimensionalArrays;

import java.util.Scanner;

public class ShufflingMatrix {
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        String dimensions=scanner.nextLine();
        int rows=Integer.parseInt(dimensions.split(" ")[0]);
        int cols=Integer.parseInt(dimensions.split(" ")[1]);
        String[][] matrix=new String[rows][cols];
        fill(matrix,scanner);
        String command=scanner.nextLine();
        while(!command.equals("END"))
        {
            if(!isValid(command,rows,cols))
            {
                System.out.println("Invalid input!");
            }else{
                String[] commandParts=command.split("\\s+");
                int row1=Integer.parseInt(commandParts[1]);
                int col1=Integer.parseInt(commandParts[2]);
                int row2=Integer.parseInt(commandParts[3]);
                int col2=Integer.parseInt(commandParts[4]);
                String first=matrix[row1][col1];
                String second=matrix[row2][col2];
                matrix[row1][col1]=second;
                matrix[row2][col2]=first;
                printMatrix(matrix);
            }
            command=scanner.nextLine();

        }
    }
    private static void fill(String[][] matrix,Scanner scanner){
        for(int r=0;r<matrix.length;r++)
        {
            matrix[r]=scanner.nextLine().split("\\s+");
        }
    }
    private static boolean isValid(String command,int rows,int cols)
    {
        String[] commandParts=command.split("\\s+");
        if(commandParts.length!=5)
        {
            return false;
        }
        if(!commandParts[0].equals("swap"))
        {
            return false;
        }
        int row1=Integer.parseInt(commandParts[1]);
        int col1=Integer.parseInt(commandParts[2]);
        int row2=Integer.parseInt(commandParts[3]);
        int col2=Integer.parseInt(commandParts[4]);
        if(row1<0 || row1>=rows||row2<0||row2>=rows||col1<0||col1>=cols||col2<0||col2>=cols)
        {
            return false;
        }
        return true;
    }
    private static void printMatrix(String[][] matrix)
    {
        for(int r=0;r<matrix.length;r++)
        {
            for(int c=0;c<matrix[r].length;c++)
            {
                System.out.print(matrix[r][c]+" ");
            }
            System.out.println();
        }
    }
}
