package ADVANCED.ExercisesMultidimensionalArrays;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class StringMatrixRotation06 {
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        //reading
        String input= scanner.nextLine();
        String line= scanner.nextLine();
        int maxLength=Integer.MIN_VALUE;
        List<String> wordList=new ArrayList<>();
        while(!line.equals("END"))
        {
            int currentWordLength=line.length();//vzimame duljinata na vuvedeniqt line
            if(currentWordLength>maxLength)
            {
                maxLength=currentWordLength;
            }
            wordList.add(line);//adding each line to a list(we make a list of words)
            line= scanner.nextLine();
        }
        //create matrix
        int row=wordList.size();//imame kolkoto redove , tolkova i dumi
        int col=maxLength;// duljinata na nai dulgata duma e ravna na broqt na kolonite
        char[][] matrix=new char[row][col];
        for(int r=0;r<row;r++)
        {
            String currentWord=wordList.get(r);//r == broqt na dumite v lista
            for(int c=0;c<col;c++)
            {
                if(c<currentWord.length())//ako nomerut na tekushtata kolona e po malka ot duljinata na dumataa shte si populvame suotvetniqt char v matricata
                {
                    char currentChar=currentWord.charAt(c);//vzimame suotvetniqt char v dumata s indeksa na suotvetnata kolona
                    matrix[r][c]=currentChar;//polagame
                }else{//ako c>curremtWorld.length -> polagame null(prazno mqsto v String matrix)
                    matrix[r][c]=' ';
                }
            }
        }
        String angleString=input.split("[()]")[1];//"90"
        int angle=Integer.parseInt(angleString);
        int angleOfRotation=angle%360;
        printMatrix(matrix,row,col,angleOfRotation);
    }
    private static void printMatrix(char[][] matrix,int rows,int cols,int angleOfRotation)
    {
        switch (angleOfRotation)
        {
            case 0:
                for(int row=0;row<rows;row++)
                {
                    for(int col=0;col<cols;col++)
                    {
                        System.out.print(matrix[row][col]);
                    }
                    System.out.println();
                }
                break;
            case 90:
                for(int col=0;col<cols;col++)
                {
                    for(int row=rows-1;row>=0;row--)
                    {
                        System.out.print(matrix[row][col]);
                    }
                    System.out.println();
                }
                break;
            case 180:
                for(int row=rows-1;row>=0;row--)
                {
                    for(int col=cols-1;col>=0;col--)
                    {
                        System.out.print(matrix[row][col]);
                    }
                    System.out.println();
                }
                break;
            case 270:
                for(int col=cols-1;col>=0;col--){
                    for(int row=0;row<rows;row++)
                    {
                        System.out.print(matrix[row][col]);
                    }
                    System.out.println();
                }
                break;
        }
    }
}
