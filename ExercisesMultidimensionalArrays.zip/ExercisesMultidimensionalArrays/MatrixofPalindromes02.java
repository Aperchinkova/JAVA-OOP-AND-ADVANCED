package ADVANCED.ExercisesMultidimensionalArrays;

import java.util.Scanner;

public class MatrixofPalindromes02 {
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        int row= scanner.nextInt();
        int col= scanner.nextInt();
        String[][] matrix=new String[row][col];
        char letter='a';
        for(int r=0;r<row;r++)
        {
            for(int c=0;c<col;c++)
            {
                String palindrome=""+letter+(char)(letter+c)+letter;
                matrix[r][c]=palindrome;
            }
            letter=(char)(letter+1);
        }
        print(matrix,row,col);
    }
    private static void print(String[][] matrix,int rows,int cols)
    {
        for(int r=0;r<rows;r++)
        {
            for(int c=0;c<cols;c++)
            {
                System.out.print(matrix[r][c]+" ");
            }
            System.out.println();
        }
    }
}
