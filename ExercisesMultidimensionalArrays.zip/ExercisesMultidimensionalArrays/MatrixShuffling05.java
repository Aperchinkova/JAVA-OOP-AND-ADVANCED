package ADVANCED.ExercisesMultidimensionalArrays;

import java.util.Arrays;
import java.util.Scanner;
import java.util.regex.Pattern;

public class MatrixShuffling05 {
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        int[] size= Arrays.stream(scanner.nextLine().split("\\s+")).mapToInt(Integer::parseInt).toArray();
        int rows=size[0];
        int cols=size[1];
        String[][] matrix=new String[rows][cols];
        for(int row=0;row<rows;row++)
        {
            String[] line=scanner.nextLine().split("\\s+");
            matrix[row]=line;
        }

        String command= scanner.nextLine();
        while(!command.equals("END"))
        {
            String[] input=command.split("\\s+");
            if(!input[0].equals("swap"))
            {
                System.out.println("Invalid input!");
                command= scanner.nextLine();
                continue;
            }
            int row1=Integer.parseInt(input[1]);
            int col1=Integer.parseInt(input[2]);
            int row2=Integer.parseInt(input[3]);
            int col2=Integer.parseInt(input[4]);

            if((input.length)!=5)
            {
                System.out.println("Invalid input!");
                command= scanner.nextLine();
                continue;
            }

            if(!isInBounds(row1,col1,row2,col2,rows,cols))
            {
                System.out.println("Invalid input!");
                command= scanner.nextLine();
                continue;
            }else
            {
                String first=matrix[row1][col1];
                String second=matrix[row2][col2];
                matrix[row1][col1]=second;
                matrix[row2][col2]=first;
                printMatrix(matrix);
            }
            command= scanner.nextLine();
        }
    }
    private static boolean isInBounds(int row1,int col1,int row2,int col2,int rows,int cols)
    {
        if(row1<0 || row1>=rows||row2<0||row2>=rows||col1<0||col1>=cols||col2<0||col2>=cols)
        {
            return false;
        }
        return true;
    }
    private static void printMatrix(String[][] matrix)
    {
        for(int r=0;r<matrix.length;r++)
        {
            for(int c=0;c<matrix[r].length;c++)
            {
                System.out.print(matrix[r][c]+" ");
            }
            System.out.println();
        }
    }
}
