package ADVANCED.ExercisesMultidimensionalArrays;

import java.util.Scanner;

public class Matrix_Shuffling_05 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String[] matrixInfo = scanner.nextLine().split("\\s+");
        int rows = Integer.parseInt(matrixInfo[0]);
        int cols = Integer.parseInt(matrixInfo[1]);

        String[][] matrix = new String[rows][cols];

        for (int row = 0; row < rows; row++) {
            String[] inputLine = scanner.nextLine().split("\\s+");
            for (int col = 0; col < cols; col++) {
                matrix[row][col] = inputLine[col];
            }
        }

        String commandLine = scanner.nextLine();
        while (!commandLine.equals("END")){
            String[] commandArr = commandLine.split("\\s+");

            if(!isValid(commandArr, rows, cols)){
                System.out.println("Invalid input!");
            }else {
                int row1 = Integer.parseInt(commandArr[1]);
                int col1 = Integer.parseInt(commandArr[2]);
                int row2 = Integer.parseInt(commandArr[3]);
                int col2 = Integer.parseInt(commandArr[4]);

                String firstElement = matrix[row1][col1];
                String secondElement = matrix[row2][col2];

                matrix[row2][col2] = firstElement;
                matrix[row1][col1] = secondElement;
                printMatrix(rows,cols,matrix);

            }
            commandLine = scanner.nextLine();
        }


    }
    private static boolean isValid(String[] command,int rows,int cols){
        if(command.length!=5){
            return false;
        }

        int row1 = Integer.parseInt(command[1]);
        int col1 = Integer.parseInt(command[2]);
        int row2 = Integer.parseInt(command[3]);
        int col2 = Integer.parseInt(command[4]);

        if(row1<0||row1>=rows || row2<0 || row2>=rows || col1<0 || col1>=cols || col2<0 || col2>=cols){
            return false;
        }

        if(!command[0].equals("swap")){
            return false;
        }

        return true;
    }

    private static void printMatrix (int rows,int cols, String[][] matrix){
        for (int row = 0; row < rows; row++) {
            for (int col = 0; col < cols; col++) {
                System.out.print(matrix[row][col] + " ");
            }
            System.out.println();
        }
    }
}
