package hotel;

import java.util.ArrayList;
import java.util.List;

public class Hotel {
    private List<Person> roster;
    private String name;
    private int capacity;

    public Hotel(String name, int capacity) {
        this.name = name;
        this.capacity = capacity;
        this.roster=new ArrayList<>();
    }
    public void add(Person person){
        if(this.roster.size()<capacity){
            roster.add(person);
        }
    }
    public boolean remove(String name){
        for(Person person:roster){
            if(person.getName().equals(name)){
                roster.remove(person);
                return true;
            }
        }
        return false;
    }
    public Person getPerson(String name,String hometown){
        Person person=null;
        for(Person person1:roster){
            if(person1.getName().equals(name) && person1.getHometown().equals(hometown)){
                person=person1;
            }
        }
        return person;
    }
    public int getCount(){
        return roster.size();
    }
    public String getStatistics(){
        StringBuilder sb=new StringBuilder();
        sb.append(String.format("The people in the hotel %s are:",this.name)).append(System.lineSeparator());
        for(Person person:roster){
            sb.append(person.toString()).append(System.lineSeparator());
        }
        return sb.toString();

    }
}
