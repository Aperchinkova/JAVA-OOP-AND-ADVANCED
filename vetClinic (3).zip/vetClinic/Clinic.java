package ADVANCED.vetClinic;

import javax.swing.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class Clinic {
    public List<Pet> data;
    private int capacity;

    public Clinic(int capacity) {
        this.capacity = capacity;
        this.data=new ArrayList<>();
    }
    public void add(Pet pet){
        if(this.data.size()<capacity){
            data.add(pet);
        }
    }
    public boolean remove(String name){
        for(Pet pet:data){
            if(pet.getName().equals(name)){
                data.remove(pet);
                return true;
            }
        }
        return false;
    }
    public Pet getPet(String name,String owner){
        /*
        Pet pet=null;
        for(Pet pet1:data){
            if(pet1.getName().equals(name) && pet1.getOwner().equals(owner)){
                pet=pet1;
            }
        }
        return pet;

         */
        return data.stream()
                .filter(p->p.getName().equals(name) && p.getOwner().equals(owner))
                .findAny()
                .orElse(null);
    }
    public Pet getOldestPet(){
        /*
        Pet pet=null;
        int oldest=Integer.MIN_VALUE;
        for(Pet pet1:data){
            if (pet1.getAge()>oldest){
                oldest= pet1.getAge();;
                pet=pet1;
            }
        }
        return pet;
        
         */
        return Collections.max(data, Comparator.comparing(Pet::getAge));

    }
    public int getCount(){
        return data.size();
    }
    public String getStatistics(){
        StringBuilder sb=new StringBuilder();
        sb.append("The clinic has the following patients:").append(System.lineSeparator());
        for(Pet pet:data){
            sb.append(String.format("%s %s",pet.getName(),pet.getOwner())).append(System.lineSeparator());
        }
        return sb.toString();
    }
}
