package reflection;

import java.lang.reflect.InvocationTargetException;
import java.sql.Ref;
import java.util.Arrays;

public class Main {
    public static void main(String[] args) throws InstantiationException, IllegalAccessException, NoSuchMethodException, InvocationTargetException {
        Class clazz= Reflection.class;

        System.out.println(clazz);
        System.out.println(clazz.getSuperclass());
        Class[] interfaces=clazz.getInterfaces();
        Arrays.stream(interfaces).forEach(System.out::println);
        Reflection ref= (Reflection) clazz.getDeclaredConstructor().newInstance();
        System.out.println(ref);
    }
}
