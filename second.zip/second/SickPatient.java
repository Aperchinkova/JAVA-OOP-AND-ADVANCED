package second;

public class SickPatient extends Patient{
    public SickPatient(String name, String address, String EGN) {
        super(name, address, EGN);
    }

    @Override
    public void cure() {

    }
}
