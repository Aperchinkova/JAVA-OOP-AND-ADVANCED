package BirthdayCelebrations;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        String command=scanner.nextLine();
        Map<Citizen,String> c=new LinkedHashMap<>();
        Map<Pet,String> p=new LinkedHashMap<>();
        while (!command.equals("End")){
            String[] input=command.split("\\s+");
            if(input.length==5){
                Citizen citizen=new Citizen(input[1],Integer.parseInt(input[2]),input[3],input[4]);
                c.put(citizen,input[4]);
            }else if(input.length==3){
                Pet pet=new Pet(input[1],input[2]);
                p.put(pet,input[2]);
            }
            command=scanner.nextLine();
        }
        String year=scanner.nextLine();
        for(String s:c.values()){
            if(s.contains(year)){
                System.out.println(s);
            }
        }
        for(String s:p.values()){
            if(s.contains(year)){
                System.out.println(s);
            }
        }
    }
}
