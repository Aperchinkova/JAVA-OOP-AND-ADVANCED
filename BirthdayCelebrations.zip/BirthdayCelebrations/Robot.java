package BirthdayCelebrations;

public class Robot implements Identifiable{
    public Robot(String id, String model) {
        this.id = id;
        this.model = model;
    }
    private String model;
    private String id;

    public String getModel() {
        return model;
    }



    @Override
    public String getId() {
        return id;
    }
}
