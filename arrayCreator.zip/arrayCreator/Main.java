package ADVANCED.arrayCreator;

public class Main {
    public static void main(String[] args) {
        String[] stringArray=ArrayCreator.<String>create(String.class,5,"Aya");
        Integer[] integerArray=ArrayCreator.create(5,12);
    }
}
