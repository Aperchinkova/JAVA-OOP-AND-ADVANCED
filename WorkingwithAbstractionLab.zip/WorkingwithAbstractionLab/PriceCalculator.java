package WorkingwithAbstractionLab;

public class PriceCalculator {
    private double pricePerDat;
    private int days;
    private Season season;
    private Discount discount;

    public PriceCalculator(double pricePerDat, int days, Season season, Discount discount) {
        this.pricePerDat = pricePerDat;
        this.days = days;
        this.season = season;
        this.discount = discount;
    }

    public double calculatePrice(){
        return pricePerDat*days*season.getMultiplier()*discount.getPriceReductionFactor();
    }

}
