package WorkingwithAbstractionLab.PointinRectangle;

public class Point {
    private int x;
    private int y;

    public Point(int x,int y){
        this.x=x;
        this.y=y;
    }

    public boolean greaterOrEqual(Point otherGiven){
        return x>=otherGiven.x && y>=otherGiven.y;
    }

    public boolean lessOrEqual(Point otherGiven){
        return x<=otherGiven.x && y<=otherGiven.y;
    }
}
