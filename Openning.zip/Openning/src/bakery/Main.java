package ADVANCED.Openning.src.bakery;

public class Main {
    public static void main(String[] args) {
        //TODO:

    }
}
