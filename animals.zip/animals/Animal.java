package animals;

public abstract class Animal {
    private String name;
    private int age;
    private String gender;



    public Animal(String name, int age, String gender) {
        this.name = name;
        this.age = age;
        this.gender = gender;
    }

    public abstract String produceSound();

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    public String getGender() {
        return gender;
    }

    @Override
    public String toString() {
        return String.format("%s %d %s",this.name,this.age,this.gender);
    }
}
