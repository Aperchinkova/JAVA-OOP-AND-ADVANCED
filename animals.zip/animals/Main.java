package animals;

import java.util.InvalidPropertiesFormatException;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws InvalidPropertiesFormatException {
        Scanner scanner=new Scanner(System.in);

        String type=scanner.nextLine();
        while (!type.equals("Beast!")){
            String[] input=scanner.nextLine().split("\\s+");
            if(Integer.parseInt(input[1])<0){
                System.out.println("Invalid input!");
                type=scanner.nextLine();
                continue;
            }
            String sound="";
            switch (type){
                case "Cat":
                    Cat cat=new Cat(input[0],Integer.parseInt(input[1]),input[2]);
                    sound= cat.produceSound();
                    print(type,input,sound);
                    break;
                case "Dog":
                    Dog dog=new Dog(input[0],Integer.parseInt(input[1]),input[2]);
                    sound=dog.produceSound();
                    print(type,input,sound);
                    break;
                case "Frog":
                    Frog frog=new Frog(input[0],Integer.parseInt(input[1]),input[2]);
                    sound=frog.produceSound();
                    print(type,input,sound);
                    break;
                default:
                    throw new InvalidPropertiesFormatException("Invalid input!");
            }
            type=scanner.nextLine();
        }
    }
    private static void print(String type,String[] input,String sound){
        System.out.println(type);
        System.out.println(String.join(" ",input));
        System.out.println(sound);
    }
}
