package animals;

public class Tomcats extends Animal{
    public Tomcats(String name, int age, String gender) {
        super(name, age, gender);
    }

    @Override
    public String produceSound() {
        return "MEOW";
    }
}
