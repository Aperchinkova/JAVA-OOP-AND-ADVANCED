package ADVANCED.StreamsFilesAndDirectoriesLab;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.util.Scanner;

public class ExtractIntegers04 {
    public static void main(String[] args) throws FileNotFoundException {
        String input="C:\\Users\\LENOVO\\Downloads\\JavaAdvanced\\src\\StreamsFilesAndDirectoriesLab\\04. Java-Advanced-Files-and-Streams-Lab-Resources\\input.txt";
        String output="C:\\Users\\LENOVO\\Downloads\\JavaAdvanced\\src\\StreamsFilesAndDirectoriesLab\\04. Java-Advanced-Files-and-Streams-Lab-Resources\\04.ExtractIntegersOutput.txt";
        Scanner scanner=new Scanner(new FileInputStream(input));
        PrintWriter myFileOutput=new PrintWriter(new FileOutputStream(output));
        while (scanner.hasNext())
        {
            if(scanner.hasNextInt()){
                int number= scanner.nextInt();
                myFileOutput.println(number);
            }
            scanner.next();
        }
        myFileOutput.close();
    }
}
