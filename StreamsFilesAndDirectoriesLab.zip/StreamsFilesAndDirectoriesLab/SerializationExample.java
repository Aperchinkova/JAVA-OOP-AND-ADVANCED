package ADVANCED.StreamsFilesAndDirectoriesLab;

import java.io.*;

public class SerializationExample {
    public static void main(String[] args) throws IOException, ClassNotFoundException {
        Cube cube=new Cube("blue",1,1,1);
        String path="C:\\Users\\LENOVO\\Downloads\\JavaAdvanced\\src\\StreamsFilesAndDirectoriesLab\\04. Java-Advanced-Files-and-Streams-Lab-Resources\\cube.ser";
        ObjectOutputStream objectOutputStream=new ObjectOutputStream(new FileOutputStream(path));
        objectOutputStream.writeObject(cube);
        objectOutputStream.close();
        ObjectInputStream objectInputStream=new ObjectInputStream(new FileInputStream(path));
        Cube cubeFromFile=(Cube)objectInputStream.readObject();

    }
}
