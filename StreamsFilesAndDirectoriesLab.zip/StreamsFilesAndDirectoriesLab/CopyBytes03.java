package ADVANCED.StreamsFilesAndDirectoriesLab;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Scanner;

public class CopyBytes03 {
    public static void main(String[] args) throws IOException {
        Scanner scanner=new Scanner(System.in);
        String input="C:\\Users\\LENOVO\\Downloads\\JavaAdvanced\\src\\StreamsFilesAndDirectoriesLab\\04. Java-Advanced-Files-and-Streams-Lab-Resources\\input.txt";
        String output="C:\\Users\\LENOVO\\Downloads\\JavaAdvanced\\src\\StreamsFilesAndDirectoriesLab\\04. Java-Advanced-Files-and-Streams-Lab-Resources\\03.CopyBytesOutput.txt";
        FileInputStream in=new FileInputStream(input);
        FileOutputStream out=new FileOutputStream(output);
        int oneByte= in.read();
        while (oneByte>=0)
        {
            if (oneByte==32 || oneByte==10)
            {
                out.write((char)oneByte);
            }else{
                String digits=String.valueOf(oneByte);
                for (int i=0;i<digits.length();i++)
                {
                    out.write(digits.charAt(i));
                }
            }
            oneByte= in.read();
        }

    }
}
