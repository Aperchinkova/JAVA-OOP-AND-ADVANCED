package ADVANCED.StreamsFilesAndDirectoriesLab;

import java.util.Scanner;

public class ReadFile01 {
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);

    }
}
