package ADVANCED.StreamsFilesAndDirectoriesLab;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Collections;
import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

public class WritetoFile02 {
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        String input="C:\\Users\\LENOVO\\Downloads\\JavaAdvanced\\src\\StreamsFilesAndDirectoriesLab\\04. Java-Advanced-Files-and-Streams-Lab-Resources\\input.txt";
        String output="C:\\Users\\LENOVO\\Downloads\\JavaAdvanced\\src\\StreamsFilesAndDirectoriesLab\\04. Java-Advanced-Files-and-Streams-Lab-Resources\\02.WriteToFileOutput.txt";
        Set<Character> forbidden=new HashSet<>();
        Collections.addAll(forbidden,',','.','!','?');
        try(FileInputStream in=new FileInputStream(input);
            FileOutputStream out=new FileOutputStream(output)){
            int oneByte= in.read();
            while (oneByte>=0)
            {
                char symbol=(char)oneByte;
                if(!forbidden.contains(symbol))
                {
                    out.write((char)oneByte);
                }
                oneByte=in.read();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
