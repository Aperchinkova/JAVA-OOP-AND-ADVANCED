package ADVANCED.StreamsFilesAndDirectoriesLab;

import java.io.*;
import java.util.Scanner;

public class WriteEveryThirdLine05 {
    public static void main(String[] args) throws IOException {
        String input="C:\\Users\\LENOVO\\Downloads\\JavaAdvanced\\src\\StreamsFilesAndDirectoriesLab\\04. Java-Advanced-Files-and-Streams-Lab-Resources\\input.txt";
        String output="C:\\Users\\LENOVO\\Downloads\\JavaAdvanced\\src\\StreamsFilesAndDirectoriesLab\\04. Java-Advanced-Files-and-Streams-Lab-Resources\\05.WriteEveryThirdLineOutput.txt";

        Scanner in=new Scanner(new FileReader(input));
        PrintWriter printing=new PrintWriter(new FileWriter(output));

        int counter=1;
        String line= in.nextLine();
        while(in.hasNextLine())
        {
            if(counter%3==0)
            {
                printing.println(line);
            }
            counter++;
            line=in.nextLine();
        }
        printing.close();
    }
}
