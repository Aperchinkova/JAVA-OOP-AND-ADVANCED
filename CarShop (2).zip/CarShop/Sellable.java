package CarShop;

public interface Sellable extends Car{
    public abstract Double getPrice();
}
