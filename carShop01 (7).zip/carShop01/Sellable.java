package carShop01;

public interface Sellable extends Car {
    public abstract Double getPrice();
}
