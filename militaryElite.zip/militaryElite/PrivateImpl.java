package militaryElite;

public class PrivateImpl extends SoldierImpl{
    private double salary;
}
