package militaryElite;

public class SoldierImpl {
    private int id;
    private String firstName;
    private String lastName;

}
