package CustomList07;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class CustomList<T extends Comparable<T>> {
    private List<T> elements;
    public CustomList()
    {
        this.elements=new ArrayList<>();
    }
    public void add(T element)
    {
        this.elements.add(element);
    }
    public T remove(int index)
    {
        return this.elements.remove(index);
    }
    public boolean contains(T element)
    {
        return this.elements.contains(element);
    }
    public void swap(int index1,int index2)
    {
        T first=this.elements.get(index1);
        T second=this.elements.get(index2);
        this.elements.set(index1,second);
        this.elements.set(index2,first);
    }
    public int countGreaterThan(T element)
    {
        int count=0;
        for(T el:elements)
        {
            if(el.compareTo(element)>0)
            {
                count++;
            }
        }
        return count;
    }
    public T getMax()
    {
        return Collections.max(elements);
    }
    public T getMin()
    {
        return Collections.min(elements);
    }
    public void print()
    {
        for(T el:elements)
        {
            System.out.println(el);
        }
    }
    public void sort(){
        this.elements.sort((e1,e2)->e1.compareTo(e2));
    }
}
