package CustomList07;



import javax.xml.crypto.dsig.spec.XSLTTransformParameterSpec;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        CustomList<String> customList=new CustomList<>();
        String command= scanner.nextLine();
        while (!command.equals("END"))
        {
            String commandType=command.split("\\s+")[0];
            switch (commandType)
            {
                case"Add":
                    String elementToAdd=command.split("\\s+")[1];
                    customList.add(elementToAdd);
                    break;
                case "Remove":
                    int indexToRemove=Integer.parseInt(command.split("\\s+")[1]);
                    customList.remove(indexToRemove);
                    break;
                case "Contains":
                    String searched=command.split("\\s+")[1];
                    System.out.println(customList.contains(searched));
                    break;
                case "Swap":
                    int first=Integer.parseInt(command.split("\\s+")[1]);
                    int second=Integer.parseInt(command.split("\\s+")[2]);
                    customList.swap(first,second);
                    break;
                case "Greater":
                    String el=command.split("\\s+")[1];
                    System.out.println(customList.countGreaterThan(el));
                    break;
                case"Max":
                    System.out.println(customList.getMax());
                    break;
                case "Min":
                    System.out.println(customList.getMin());
                    break;
                case "Print":
                    customList.print();
                    break;
                case "Sort":
                    customList.sort();
            }
            command= scanner.nextLine();
        }
    }
}
