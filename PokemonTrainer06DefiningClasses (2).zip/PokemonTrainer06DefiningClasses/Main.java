package PokemonTrainer06DefiningClasses;

import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);

        String input=scanner.nextLine();

        Map<String, Trainer> trainers=new LinkedHashMap<>();//key-imeto na trainer,value-object trainer

        while (!input.equals("Tournament"))
        {
            String[] parts=input.split("\\s+");
            String trainerName=parts[0];
            String pokemonName=parts[1];
            String pokemonElement=parts[2];
            int pokemonHealth=Integer.parseInt(parts[3]);

            Trainer trainer=new Trainer(trainerName);
            Pokemon pokemon=new Pokemon(pokemonName,pokemonElement,pokemonHealth);
            trainers.putIfAbsent(trainerName,trainer);
            trainers.get(trainerName).addPokemons(pokemon);

            input= scanner.nextLine();
        }

        String command=scanner.nextLine();
        while (!command.equals("End"))
        {
            String element=command;
            for(Trainer trainer:trainers.values())
            {
                if(trainer.hasElement(element)){
                    trainer.incrementBadge(1);
                }else{
                    trainer.decrementHealth(10);
                }
            }
            command= scanner.nextLine();
        }
        trainers
                .entrySet()
                .stream()
                .sorted((f,s)->
                        s.getValue().getBadges()-f.getValue().getBadges())
                .forEach(entry-> System.out.println(entry.getValue().toString()));
    }
}
