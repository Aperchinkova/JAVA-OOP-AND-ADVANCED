package RawData04DefiningClassesExc;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        int n=Integer.parseInt(scanner.nextLine());
        List<Car> cars=new ArrayList<>();
        for(int i=0;i<n;i++)
        {
            String[] parts=scanner.nextLine().split("\\s+");
            String model=parts[0];

            int engineSpeed=Integer.parseInt(parts[1]);
            int enginePower=Integer.parseInt(parts[2]);
            Engine engine=new Engine(engineSpeed,enginePower);

            int cargoWeight=Integer.parseInt(parts[3]);
            String cargoType=parts[4];
            Cargo cargo=new Cargo(cargoWeight,cargoType);

            List<Tire> tires=new ArrayList<>();
            for (int j=5;j<parts.length;j+=2)
            {
                double pressure=Double.parseDouble(parts[j]);
                int age=Integer.parseInt(parts[j+1]);
                Tire tire=new Tire(pressure,age);
                tires.add(tire);
            }
            Car car=new Car(model,tires,engine,cargo);
            cars.add(car);
        }
        String cargoType=scanner.nextLine();
        if(cargoType.equals("fragile"))
        {
            cars.stream()
                    .filter(car->car.getCargo().getType().equals("fragile"))
                    .filter(car->car.getTires().stream().anyMatch(tire -> tire.getPressure()<1))
                    .forEach(car-> System.out.println(car.getModel()));
        }else if(cargoType.equals("flamable"))
        {
            cars.stream()
                    .filter(car->car.getCargo().getType().equals("flamable"))
                    .filter(car -> car.getEngine().getPower()>250)
                    .forEach(car-> System.out.println(car.getModel()));
        }
    }
}
