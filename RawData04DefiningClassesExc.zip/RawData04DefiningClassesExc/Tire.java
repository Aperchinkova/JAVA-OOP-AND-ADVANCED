package ADVANCED.RawData04DefiningClassesExc;

public class Tire {
    private double pressure;
    private int age;

    public Tire(double pressure,int age)
    {
        this.pressure=pressure;
        this.age=age;
    }
    public void setAge(int age)
    {
        this.age=age;
    }
    public int getAge()
    {
        return this.age;
    }
    public void setPressure(double pressure)
    {
        this.pressure=pressure;
    }
    public double getPressure()
    {
        return this.pressure;
    }


}
