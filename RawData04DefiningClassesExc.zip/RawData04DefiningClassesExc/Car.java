package RawData04DefiningClassesExc;

import java.util.List;

public class Car {
    private String model;
    public List<Tire> tires;

    public String getModel() {
        return model;
    }

    public List<Tire> getTires() {
        return tires;
    }

    public Engine getEngine() {
        return engine;
    }

    public Cargo getCargo() {
        return cargo;
    }

    public Engine engine;
    public Cargo cargo;

    public Car(String model, List<Tire> tires, Engine engine, Cargo cargo) {
        this.model = model;
        this.tires=tires;
        this.engine = engine;
        this.cargo = cargo;
    }




}
