package aquarium.src.main.java.aquarium.core;

public interface Engine extends Runnable {
}

