package aquarium.src.main.java.aquarium.entities.decorations;

public interface Decoration {
    int getComfort();

    double getPrice();
}
