package first;

public interface IsLandVehicle {
    void enterLand();
}
