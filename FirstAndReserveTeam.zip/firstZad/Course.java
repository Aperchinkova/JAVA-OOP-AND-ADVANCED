package firstZad;

public class Course {
    private String biology;
    private String math;
    private String name;

    public Course(String name, String biology, String math) {
        this.name = name;
        this.biology = biology;
        this.math = math;
    }


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getBiology() {
        return biology;
    }

    public void setBiology(String biology) {
        this.biology = biology;
    }

    public String getMath() {
        return math;
    }

    public void setMath(String math) {
        this.math = math;
    }




}
