package fourthZad;

public class Multiprocessor {
    private int processorsCount;
    private int corePerProcessor;
    private int tactovaChestota;

    public Multiprocessor(int processorsCount, int corePerProcessor, int tactovaChestota) {
        this.processorsCount = processorsCount;
        this.corePerProcessor = corePerProcessor;
        this.tactovaChestota = tactovaChestota;
    }

    public int getProcessorsCount() {
        return processorsCount;
    }

    public void setProcessorsCount(int processorsCount) {
        this.processorsCount = processorsCount;
    }

    public int getCorePerProcessor() {
        return corePerProcessor;
    }

    public void setCorePerProcessor(int corePerProcessor) {
        this.corePerProcessor = corePerProcessor;
    }

    public int getTactovaChestota() {
        return tactovaChestota;
    }

    public void setTactovaChestota(int tactovaChestota) {
        this.tactovaChestota = tactovaChestota;
    }
    public double preobrazuvane(int tactovaChestota){
        if(corePerProcessor>1 && processorsCount>1){
            return (0.7*corePerProcessor)*(0.8*processorsCount)*tactovaChestota;
        }   else{
            return (1.0*corePerProcessor)*(1.0*processorsCount)*tactovaChestota;
        }
    }
    public int time(int seconds){
        return (seconds*tactovaChestota)/tactovaChestota;
    }

    @Override
    public String toString() {
        return String.format("Processor count = %d,Core per processor=%d,Tacts: %d",processorsCount,corePerProcessor,tactovaChestota);
    }
}
