package firstExc;

public class CStudent {
    private int[] student_List=new int[30];

    private String courseName;



}
