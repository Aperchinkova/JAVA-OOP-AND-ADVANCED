package foodShortage;

public interface Identifiable {
    String getId();
}
