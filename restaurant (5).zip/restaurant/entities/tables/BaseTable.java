package restaurant.entities.tables;

import restaurant.common.ExceptionMessages;
import restaurant.entities.drinks.interfaces.Beverages;
import restaurant.entities.healthyFoods.Food;
import restaurant.entities.healthyFoods.interfaces.HealthyFood;
import restaurant.entities.tables.interfaces.Table;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

public abstract class BaseTable implements Table {
    private List<HealthyFood> healthyFood;
    private List<Beverages> beverages;

    private int numberOfPeople;


    private int number;
    private int size;


    private double 	pricePerPerson;
    private boolean isReservedTable;
    private double 	allPeople;// the price for all people


    public BaseTable(int number, int size, double pricePerPerson) {
        this.setNumber(number);
        this.setSize(size);
        this.setPricePerPerson(pricePerPerson);
        this.healthyFood=new ArrayList<>();
        this.beverages=new ArrayList<>();
    }

    private void setPricePerPerson(double pricePerPerson) {
        this.pricePerPerson = pricePerPerson;
    }
    private void setNumberOfPeople(int numberOfPeople) {
        if(numberOfPeople<=0){
            throw new IllegalArgumentException(ExceptionMessages.INVALID_NUMBER_OF_PEOPLE);
        }
        this.numberOfPeople = numberOfPeople;
    }

    private int getNumber() {
        return number;
    }

    private void setNumber(int number) {
        this.number = number;
    }


    private void setSize(int size) {
        if(size<0){
            throw new IllegalArgumentException(ExceptionMessages.INVALID_TABLE_SIZE);
        }
        this.size = size;
    }



    @Override
    public int getTableNumber() {
        return number;
    }

    @Override
    public int getSize() {
        return size;
    }

    @Override
    public int numberOfPeople() {
        return numberOfPeople;
    }

    @Override
    public double pricePerPerson() {
        return pricePerPerson;
    }

    @Override
    public boolean isReservedTable() {
        return false;
    }

    @Override
    public double allPeople() {
        return allPeople;
    }

    @Override
    public void reserve(int numberOfPeople) {
        if(numberOfPeople<=0){
            throw new IllegalArgumentException(ExceptionMessages.INVALID_NUMBER_OF_PEOPLE);
        }
        this.numberOfPeople=numberOfPeople;
        this.isReservedTable=true;
    }

    @Override
    public void orderHealthy(HealthyFood food) {
        healthyFood.add(food);
    }

    @Override
    public void orderBeverages(Beverages bev) {
        beverages.add(bev);
    }

    @Override
    public double bill() {
        double foodPrice=healthyFood.stream().mapToDouble(HealthyFood::getPrice).sum();
        double bevPrice=beverages.stream().mapToDouble(Beverages::getPrice).sum();
        return foodPrice+bevPrice;
    }

    @Override
    public void clear() {
        //Removes all the ordered drinks and food and finally frees the table,
        // the table is not reserved, sets the count of people and price to 0.
        this.isReservedTable=false;
        healthyFood.clear();
        beverages.clear();
        this.numberOfPeople=0;
        this.pricePerPerson=0;
    }

    @Override
    public String tableInformation() {
        //Return a String with the following format:
        //"Table - {table number}
        //Size - {table size}
        //Type - {table type}
        //All price - {price per person for the current table}"
        StringBuilder sb=new StringBuilder();
        sb.append(String.format("Table - "+number)).append(System.lineSeparator());
        sb.append(String.format("Size - "+size)).append(System.lineSeparator());
        sb.append(String.format("All price - %.2f",pricePerPerson));
        return sb.toString();
    }
}
