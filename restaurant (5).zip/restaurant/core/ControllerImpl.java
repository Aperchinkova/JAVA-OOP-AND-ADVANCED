package restaurant.core;

import restaurant.common.ExceptionMessages;
import restaurant.common.OutputMessages;
import restaurant.core.interfaces.Controller;
import restaurant.entities.drinks.Fresh;
import restaurant.entities.drinks.Smoothie;
import restaurant.entities.healthyFoods.Food;
import restaurant.entities.healthyFoods.Salad;
import restaurant.entities.healthyFoods.VeganBiscuits;
import restaurant.entities.healthyFoods.interfaces.HealthyFood;
import restaurant.entities.drinks.interfaces.Beverages;
import restaurant.entities.tables.InGarden;
import restaurant.entities.tables.Indoors;
import restaurant.entities.tables.interfaces.Table;
import restaurant.repositories.BeverageRepositoryImpl;
import restaurant.repositories.HealthFoodRepositoryImpl;
import restaurant.repositories.TableRepositoryImpl;
import restaurant.repositories.interfaces.*;

import java.util.Collection;

public class ControllerImpl implements Controller {



    private HealthFoodRepository<HealthyFood> healthFoodRepository;
    private BeverageRepository<Beverages> beverageRepository;
    private TableRepository<Table> tableRepository;
    private double profit;

    public ControllerImpl(HealthFoodRepository<HealthyFood> healthFoodRepository, BeverageRepository<Beverages> beverageRepository, TableRepository<Table> tableRepository) {
        this.healthFoodRepository=healthFoodRepository;
        this.beverageRepository=beverageRepository;
        this.tableRepository=tableRepository;
    }

    @Override
    public String addHealthyFood(String type, double price, String name) {
        //TODO:
        //Creates food with the correct type. If the food is created
        // successfully add it to the food repository and returns:
        //"Added {name} to the healthy menu!"
        //If a healthy food with the given name already exists in the food repository,
        // throw an IllegalArgumentException with the message "{name} is already in the healthy menu!"
        HealthyFood food = null;
        switch (type){
            case "Salad":
                food=new Salad(name,price);
                break;
            case "VeganBiscuits":
                food=new VeganBiscuits(name,price);
                break;
        }
        if(healthFoodRepository.foodByName(name)==null) {
            healthFoodRepository.add(food);
            return String.format(OutputMessages.FOOD_ADDED, name);
        }
        throw new IllegalArgumentException(String.format(ExceptionMessages.FOOD_EXIST,name));

    }

    @Override
    public String addBeverage(String type, int counter, String brand, String name){
        //TODO:
        //Creates a beverage with the correct type. If the beverage is created successful, returns:
        //"Added {type} - {brand} to the beverage menu!"
        //If a beverage with the given name already exists in the beverage repository,
        // throw an IllegalArgumentException with the message "{name} is already in the beverage menu!"
        Beverages beverages=null;
        switch (type){
            case "Fresh":
                beverages=new Fresh(name,counter,brand);
                break;
            case "Smoothie":
                beverages=new Smoothie(name,counter,brand);
                break;
        }
        if(beverageRepository.beverageByName(name,brand)==null){
            beverageRepository.add(beverages);
            return String.format(OutputMessages.BEVERAGE_ADDED,type,brand);
        }
        throw new IllegalArgumentException(String.format(ExceptionMessages.BEVERAGE_EXIST,name));

    }

    @Override
    public String addTable(String type, int tableNumber, int capacity) {
        //TODO:
        //Creates a table with the correct type and returns:
        //"Added table number {number} in the healthy restaurant!"
        //If a table with the given number already exists in the table repository,
        // throw an IllegalArgumentException with the message "Table {number} is already added to the healthy restaurant!"
        Table table=null;
        switch (type){
            case "Indoors":
                table=new Indoors(tableNumber,capacity);
                break;
            case "InGarden":
                table=new InGarden(tableNumber,capacity);
                break;
        }
        if(tableRepository.byNumber(tableNumber)==null){
            tableRepository.add(table);
            return String.format(OutputMessages.TABLE_ADDED,tableNumber);
        }
        throw new IllegalArgumentException(String.format(ExceptionMessages.TABLE_IS_ALREADY_ADDED,tableNumber));
    }

    @Override
    public String reserve(int numberOfPeople) {
        //TODO:
        //Finds a table which is not reserved, and its size is enough for the number of people provided.
        // If there is no such table returns:
        //"There is no such table for {numberOfPeople} people."
        //In the other case reserves the table and returns:
        //"Table {number} has been reserved for {numberOfPeople} people."
        Collection<Table> tables=tableRepository.getAllEntities();
        Table table = tables.stream().filter(e -> !e.isReservedTable() && e.getSize() >= numberOfPeople)
                .findFirst().orElse(null);
        String message=String.format(OutputMessages.RESERVATION_NOT_POSSIBLE,numberOfPeople);
        if(table!=null){
            message=String.format(OutputMessages.TABLE_RESERVED,table.getSize(),numberOfPeople);
            table.reserve(numberOfPeople);
        }
        return message;
    }
    @Override
    public String orderHealthyFood(int tableNumber, String healthyFoodName) {
        //TODO:
        //Finds the table with that number and the food with that name on the menu.
        // You first check if the table exists. If there are no such table returns:
        //"Could not find table {tableNumber}."
        //If there are no such food returns:
        //"No {healthyFoodName} in the healthy menu."
        //In other cases orders the food for that table and returns:
        //"{healthyFoodName} ordered from table {tableNumber}."
        Table table = tableRepository.byNumber(tableNumber);
        if(table==null){
            return String.format(OutputMessages.WRONG_TABLE_NUMBER,tableNumber);
        }
        HealthyFood food=healthFoodRepository.foodByName(healthyFoodName);
        if(food==null){
            return String.format(OutputMessages.NONE_EXISTENT_FOOD,healthyFoodName);
        }
        table.orderHealthy(food);
        return String.format(OutputMessages.FOOD_ORDER_SUCCESSFUL,healthyFoodName,tableNumber);

    }

    @Override
    public String orderBeverage(int tableNumber, String name, String brand) {
        //TODO:
        //Finds the table with that number and find the beverage with that name and brand.
        // You first check if the table exists. If there is no such table, it returns:
        //"Could not find table {tableNumber}."
        //If there isn’t such beverage, it returns:
        //"No {name} - {brand} in the beverage menu."
        //In another case, it orders the beverage for that table and returns:
        //"{name} ordered from table {tableNumber}."
        Table table = tableRepository.byNumber(tableNumber);
        if(table==null){
            return String.format(OutputMessages.WRONG_TABLE_NUMBER,tableNumber);
        }
        Beverages beverages= beverageRepository.beverageByName(name,brand);
        if(beverages==null){
            return String.format(OutputMessages.NON_EXISTENT_DRINK,name,brand);
        }
        table.orderBeverages(beverages);
        return String.format(OutputMessages.BEVERAGE_ORDER_SUCCESSFUL,name,tableNumber);

    }

    @Override
    public String closedBill(int tableNumber) {
        //TODO:
        //Finds the table with the same table number. Gets the bill for that table and clears it. Finally returns:
        //"Table: {tableNumber} with bill: {table bill formatted to the second digit}."
         Table table = tableRepository.byNumber(tableNumber);
        double bill=table.bill();
        table.clear();
        profit+=bill;
        return String.format(OutputMessages.BILL,tableNumber,bill);
    }


    @Override
    public String totalMoney() {
        //TODO:
        //Returns the money earned for the restaurant for all completed bills.
        //"Total money for the restaurant: {money formatted to the second digit}lv."
        return String.format(OutputMessages.TOTAL_MONEY,profit);
    }
}
