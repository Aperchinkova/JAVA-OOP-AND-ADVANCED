package secondZad;

public class Student extends People {
    private String fakultetenNomer;
    private double PIKocenka;
    private double TEocenka;
    private double PPEocenka;

    public Student(String name, String birthDate,String fakultetenNomer,double PIKocenka,double TEocenka,double PPEocenka) {
        super(name, birthDate);
        this.fakultetenNomer=fakultetenNomer;
        this.PIKocenka=PIKocenka;
        this.TEocenka=TEocenka;
        this.PPEocenka=PPEocenka;
    }

    public String getFakultetenNomer() {
        return fakultetenNomer;
    }

    public void setFakultetenNomer(String fakultetenNomer) {
        this.fakultetenNomer = fakultetenNomer;
    }

    public double getPIKocenka() {
        return PIKocenka;
    }

    public void setPIKocenka(double PIKocenka) {
        this.PIKocenka = PIKocenka;
    }

    public double getTEocenka() {
        return TEocenka;
    }

    public void setTEocenka(double TEocenka) {
        this.TEocenka = TEocenka;
    }

    public double getPPEocenka() {
        return PPEocenka;
    }

    public void setPPEocenka(double PPEocenka) {
        this.PPEocenka = PPEocenka;
    }
    public double examinePik(double PIKocenka){
        return PIKocenka;
    }
    public double examineTE(double TEocenka){
        return TEocenka;
    }
    public double examinePPE(double PPEocenka){
        return  PPEocenka;
    }

    @Override
    public String toString() {
        return String.format("%s born on  %s with facylty number %s has results on PIK,TE,PPE:%.2f,%.2f,%.2f",getName(),getBirthDate(),getFakultetenNomer(),PIKocenka,TEocenka,PPEocenka);
    }
}
