package secondZad;

public class Main {
    public static void main(String[] args) {
        Student student=new Student("Dean","03.11.2003","121234657",3.50,4.00,6.00);
        System.out.println(student.toString());
        System.out.println("Examined and got "+student.examinePik(5.50)+" on PIK");
        System.out.println("Examined and got "+student.examineTE(6.00)+ " on TE");
        System.out.println("Examined and got "+student.examinePPE(4.00)+" on PPE");

    }
}
