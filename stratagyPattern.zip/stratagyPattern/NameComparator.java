package stratagyPattern;

import java.util.Comparator;

public class NameComparator implements Comparator<Person> {

    @Override
    public int compare(Person firstName, Person secondName) {
        if(firstName.getName().length()==secondName.getName().length()){
            char firstPersonChar=firstName.getName().toLowerCase().charAt(0);
            char secondPersonChar=secondName.getName().toLowerCase().charAt(0);
            return Character.compare(firstPersonChar,secondPersonChar);
        }
        return Integer.compare(firstName.getName().length(),secondName.getName().length());
    }
}
