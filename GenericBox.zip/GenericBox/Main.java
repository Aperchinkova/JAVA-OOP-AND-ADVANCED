package ADVANCED.GenericBox;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        int n=Integer.parseInt(scanner.nextLine());
        /*
        Box<String> box=new Box<>();
        for(int i=0;i<n;i++)
        {
            String text= scanner.nextLine();
            box.add(text);
        }
        System.out.println(box);

        /*


        Box<Integer> box=new Box<>();
        for(int i=0;i<n;i++)
        {
            int number= Integer.parseInt(scanner.nextLine());
            box.add(number);
        }
        System.out.println(box);

         */
        /*
        Box<String> box=new Box<>();
        for(int i=0;i<n;i++)
        {
            String text= scanner.nextLine();
            box.add(text);
        }
        int first= scanner.nextInt();
        int second=scanner.nextInt();
        box.swap(first,second);
        System.out.println(box);
        */
        /*
        Box<Integer> box=new Box<>();
        for(int i=0;i<n;i++)
        {
            int number= Integer.parseInt(scanner.nextLine());
            box.add(number);
        }
        int first= scanner.nextInt();
        int second=scanner.nextInt();
        box.swap(first,second);
        System.out.println(box);

         */
        /*
        Box<String > box=new Box<>();
        for(int i=0;i<n;i++)
        {
            String text= scanner.nextLine();
            box.add(text);
        }
        String element=scanner.nextLine();
        System.out.println(box.countGreaterThan(element));

         */
        Box<Double > box=new Box<>();
        for(int i=0;i<n;i++)
        {
            Double num= Double.parseDouble(scanner.nextLine());
            box.add(num);
        }
        Double element=Double.parseDouble(scanner.nextLine());
        System.out.println(box.countGreaterThan(element));
    }
}
