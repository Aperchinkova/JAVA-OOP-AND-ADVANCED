package ADVANCED.GenericBox;

import java.util.ArrayList;
import java.util.List;

public class Box <T extends Comparable<T>>{
    private List<T> list;
    public Box(){
        this.list=new ArrayList<>();
    }
    public void add(T element){
        this.list.add(element);
    }
    public void swap(int index1,int index2)
    {
        T first=this.list.get(index1);
        T second=this.list.get(index2);
        this.list.set(index1,second);
        this.list.set(index2,first);

    }
    public int countGreaterThan(T element)
    {
        int count=0;
        for(T el:list)
        {
            if(el.compareTo(element)>0)
            {
                count++;
            }
        }
        return count;
    }
    @Override
    public String toString(){
        StringBuilder sb=new StringBuilder();;
        for(T el:list)
        {
          sb.append(el.getClass().getName()+": "+el).append("\n");
        }
        return sb.toString();
    }
}
