package university;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class University {
    public List<Student> students;
    public int capacity;

    public List<Student> getStudents() {
        return students;
    }

    public int getCapacity() {
        return capacity;
    }


    public University(int capacity) {
        this.capacity = capacity;
        this.students=new ArrayList<>();
    }

    public int getStudentCount(){
        return students.size();
    }
   public String registerStudent(Student student){
       String result=null;
       if(getStudentCount()>=capacity){
           result="No seats in the university";
       }
       /*
       for(Student s:students){
           if(s.getFirstName().equals(student.getFirstName()) && s.getLastName().equals(student.getLastName())){
               result="Student is already in the university";
           }
       }

        */
       if(getStudent(student.firstName,student.lastName)!=null){
           result="Student is already in the university";
       }

       if(result==null){
           students.add(student);
           result="Added student "+student.getFirstName()+" "+student.getLastName();
       }
       return result;
   }
    public String dismissStudent(Student student){
        /*
        for(Student s:students){
            if(s.equals(student)){
                students.remove(s);
            }
        }
        return "Student not found";

         */
        Student foundStudent=getStudent(student.getFirstName(),student.getLastName());
        if(foundStudent==null){
            return "Student not found";
        }
        students.remove(foundStudent);
        return "Removed student "+foundStudent.getFirstName()+" "+foundStudent.getLastName();

    }
    public Student getStudent(String firstName, String lastName){
        for(Student student:students){
            if(firstName.equals(student.getFirstName()) && lastName.equals(student.getLastName())){
                return student;
            }
        }
        return null;
    }
    public String getStatistics(){
        /*
        StringBuilder sb=new StringBuilder();
        for (Student s:students){
            sb.append(String.format("==Student: First Name = %s, Last Name = %s, Best Subject = %s",s.getFirstName(),s.getLastName(),s.getBestSubject())).append(System.lineSeparator());
        }
        return sb.toString();

         */
        return students.stream()
                .map(s->String.format(
                        "==Student: First Name = %s, Last Name = %s, Best Subject = %s",
                        s.getFirstName(),s.getLastName(),s.getBestSubject()))
                .collect(Collectors.joining(System.lineSeparator()));
    }
}
