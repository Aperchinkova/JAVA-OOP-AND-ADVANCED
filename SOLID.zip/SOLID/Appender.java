package SOLID;

public interface Appender {
    void append(String dataTime,ReportLevel reportLevel,String message);
    void setReportLevel(ReportLevel reportLevel);
}
