package SOLID;

public class SimpleLayout implements Layout{
    @Override
    public String format(String dataTime, ReportLevel reportLevel, String message) {
        return String.format("%s - %s - %s",dataTime,reportLevel,message);
    }

}
