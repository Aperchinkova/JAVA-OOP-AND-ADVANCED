package SOLID;

public interface Factory<T> {
    T produce(String input);

}
