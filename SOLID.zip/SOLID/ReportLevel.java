package SOLID;

public enum ReportLevel {
    INFO,
    WARNING,
    ERROR,
    CRITICAL,
    FATAL
}
