package SOLID;

public interface Layout {
    String format(String time,ReportLevel reportLevel,String message);
}
