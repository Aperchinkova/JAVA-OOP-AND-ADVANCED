package SOLID;

import java.util.Scanner;

public class ConsoleAppender extends  BaseAppender{

    public ConsoleAppender(Layout layout) {
        super(layout);
    }

    @Override
    public void append(String dataTime, ReportLevel reportLevel,String message) {
        if(canAppend(reportLevel)){
            String appender=layout.format(dataTime,reportLevel,message);
            increaseMessageCount();
            System.out.println(appender);
        }

    }
}
