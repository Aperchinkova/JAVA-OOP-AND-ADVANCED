package borderControl;

import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        String command=scanner.nextLine();

        Map<Citizen,String> c=new LinkedHashMap<>();
        Map<Robot,String> r=new LinkedHashMap<>();
        while (!command.equals("End")){
            String[] input=command.split("\\s+");
            if(input.length==3){
                Citizen citizen=new Citizen(input[0],Integer.parseInt(input[1]),input[2]);
                c.put(citizen,input[2]);
            }else if(input.length==2){
                Robot robot=new Robot(input[0],input[1]);
                r.put(robot,input[1]);
            }
            command=scanner.nextLine();
        }
        String num=scanner.nextLine();
        for (String s:c.values()){
            if(s.substring(s.length()-3).equals(num)){
                System.out.println(s);
            }
        }
        for (String s:r.values()){
            if(s.substring(s.length()-3).equals(num)){
                System.out.println(s);
            }
        }

    }
}
