package vehiclesExtension;


import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        //creates a car
        String[] input = scanner.nextLine().split("\\s+");
        Vehicle car = createVehicle(input);

        //creates a vehicle
        input = scanner.nextLine().split("\\s+");
        Vehicle truck=createVehicle(input);

        input = scanner.nextLine().split("\\s+");
        Vehicle bus=createVehicle(input);

        int n = Integer.parseInt(scanner.nextLine());

        Map<String,Vehicle> vehicles=new LinkedHashMap();
        vehicles.put("Car",car);
        vehicles.put("Truck",truck);
        vehicles.put("Bus",bus);

        for (int i=0;i<n;i++){
            input=scanner.nextLine().split("\\s+");
            String type=input[1];
            switch (input[0]){
                case "Drive":
                    double km=Double.parseDouble(input[2]);
                    Vehicle vehicle=vehicles.get(type);
                    if(vehicle instanceof Bus){
                        ((Bus) vehicle).setEmpty(false);
                    }
                    System.out.println(vehicles.get(type).driving(km));
                    break;
                case "Refuel":
                    double fuel=Double.parseDouble(input[2]);
                    vehicles.get(type).refueling(fuel);
                    break;
                case "DriveEmpty":
                    double distance=Double.parseDouble(input[2]);
                    Vehicle vehicle1=vehicles.get(type);
                    if(vehicle1 instanceof Bus){
                        ((Bus) vehicle1).setEmpty(true);
                    }
                    System.out.println(vehicles.get(type).driving(distance));
                    break;
            }
        }
        vehicles.values().stream().forEach(System.out::println);
    }

    private static Vehicle createVehicle(String[] input) {

        double fuelQuantity=Double.parseDouble(input[1]);
        double consumption=Double.parseDouble(input[2]);
        double tankCapacity=Double.parseDouble(input[3]);
        String type=input[0];
        Vehicle vehicle=null;

        switch (type){
            case "Car":
                vehicle=new Car(fuelQuantity,consumption,tankCapacity);
                break;
            case "Truck":
                vehicle=new Truck(fuelQuantity,consumption,tankCapacity);
                break;
            case "Bus":
                vehicle=new Bus(fuelQuantity,consumption,tankCapacity);
                break;
        }
        return vehicle;
    }

}
