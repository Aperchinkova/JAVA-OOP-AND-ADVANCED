package vehiclesExtension;

import java.text.DecimalFormat;

public  class Vehicle {
    protected double fuelQuantity;
    protected double fuelConsumptionInLitersPerKm;
    protected double tankCapacity;

    public Vehicle(double fuelQuantity, double fuelConsumptionInLitersPerKm, double tankCapacity) {
        this.fuelQuantity = fuelQuantity;
        this.fuelConsumptionInLitersPerKm = fuelConsumptionInLitersPerKm;
        this.tankCapacity = tankCapacity;
    }

    public double getTankCapacity() {
        return tankCapacity;
    }

    public void setTankCapacity(double tankCapacity) {
        this.tankCapacity = tankCapacity;
    }

    public double getFuelQuantity() {
        return fuelQuantity;
    }

    public void setFuelQuantity(double fuelQuantity) {
        this.fuelQuantity = fuelQuantity;
    }

    public double getFuelConsumptionInLitersPerKm() {
        return fuelConsumptionInLitersPerKm;
    }

    public void setFuelConsumptionInLitersPerKm(double fuelConsumptionInLitersPerKm) {
        this.fuelConsumptionInLitersPerKm = fuelConsumptionInLitersPerKm;
    }

    public String  driving(double km){

        double fuelNeeded=km*fuelConsumptionInLitersPerKm;

        if(fuelNeeded>this.fuelQuantity){
            return String.format("%s needs refueling",this.getClass().getSimpleName());
        }

        if(fuelQuantity-fuelNeeded<=0){
            System.out.println("Fuel must be a positive number");
        }else{
            this.fuelQuantity=this.fuelQuantity-fuelNeeded;
        }

        DecimalFormat decimalFormat=new DecimalFormat("##.##");

        return String.format("%s travelled %s km",this.getClass().getSimpleName(),decimalFormat.format(km));
    }

    public  void refueling(double fuel){
        if(fuel<=0){
            System.out.println("Fuel must be a positive number");
            return;

        }
        if(fuel>tankCapacity-fuelQuantity){
            System.out.println("Cannot fit fuel in tank");
            return;
        }else{

            this.fuelQuantity+=fuel;
        }
    }

    @Override
    public String toString() {
        return String.format("%s: %.2f",getClass().getSimpleName(),fuelQuantity);
    }

}
