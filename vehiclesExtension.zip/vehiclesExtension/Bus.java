package vehiclesExtension;

public class Bus extends Vehicle{

    private static final double AC_ADDITIONAL_CONSUMPTION = 1.4;
    private boolean isEmpty;

    public Bus(double fuelQuantity, double fuelConsumption, double tankCapacity) {
        super(fuelQuantity, fuelConsumption, tankCapacity);
        isEmpty=true;
    }
    public boolean isEmpty() {
        return isEmpty;
    }

    public void setEmpty(boolean empty) {
        if(isEmpty && !empty){
            super.setFuelConsumptionInLitersPerKm(super.getFuelConsumptionInLitersPerKm()+AC_ADDITIONAL_CONSUMPTION);
        }
        if(!isEmpty && empty){
            super.setFuelConsumptionInLitersPerKm(super.getFuelConsumptionInLitersPerKm()-AC_ADDITIONAL_CONSUMPTION);
        }
        isEmpty = empty;
    }


}
