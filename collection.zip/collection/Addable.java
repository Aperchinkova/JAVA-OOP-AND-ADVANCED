package collection;

public interface Addable {
    int add(String text);
}
