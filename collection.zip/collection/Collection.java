package collection;

import java.util.ArrayList;
import java.util.List;

public abstract class Collection {

    protected int maxSize;

    public List<String> getItems() {
        return items;
    }

    protected List<String> items;
    public Collection() {
        this.maxSize = 100;
        this.items=new ArrayList<>();
    }

}
