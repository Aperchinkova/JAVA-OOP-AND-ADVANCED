package collection;

public interface AddRemovable extends Addable{
    String remove();
}
