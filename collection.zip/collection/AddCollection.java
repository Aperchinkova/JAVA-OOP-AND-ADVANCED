package collection;

public class AddCollection extends Collection implements Addable{
    @Override
    public int add(String text) {
        items.add(text);
        return items.indexOf(text);
    }
}
