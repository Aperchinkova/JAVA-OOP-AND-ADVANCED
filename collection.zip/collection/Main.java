package collection;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        String[] input=scanner.nextLine().split("\\s+");
        int n=Integer.parseInt(scanner.nextLine());
        AddCollection addCollection=new AddCollection();
        AddRemoveCollection addRemoveCollection=new AddRemoveCollection();
        MyListImpl myList=new MyListImpl();
        printAdd(input,addCollection);
        printAdd(input,addRemoveCollection);
        printAdd(input,myList);
        
        printRemove(n,addRemoveCollection);
        printRemove(n,myList);
    }

    private static void printRemove(int n,AddRemovable collection) {
        for(int i=0;i<n;i++){
            System.out.print(collection.remove()+" ");
        }
        System.out.println();
    }


    private static void printAdd(String[] input, Addable collection) {
        for(String  s:input){
            System.out.print(collection.add(s)+" ");
        }
        System.out.println();
    }
}
