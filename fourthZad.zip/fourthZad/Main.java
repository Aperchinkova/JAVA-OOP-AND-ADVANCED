package fourthZad;

public class Main {
    public static void main(String[] args) {
        Multiprocessor multiprocessor=new Multiprocessor(64,8,69);
        System.out.println(multiprocessor.toString());
        System.out.println(multiprocessor.time(64));
        System.out.println(multiprocessor.preobrazuvane(multiprocessor.getTactovaChestota()));
    }
}
