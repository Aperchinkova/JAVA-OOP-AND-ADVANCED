package garage;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

public class GarageTests {
    //TODO: Test Garage class
    private Garage garage;
    private Car porsche;
    private Car mercedes;
    private Car toyota;

    @Before
    public void setup(){
        this.garage=new Garage();
        porsche=new Car("porsche",280,150.00);
        mercedes=new Car("mercedes",300,200.00);
        toyota=new Car("toyota",170,300.00);
        toyota=new Car("toyota",180,180.00);
        garage.addCar(porsche);
        garage.addCar(mercedes);
        garage.addCar(toyota);
    }

    @Test
    public void testGetCars(){

        Car car=new Car("Kiki",280,123.44);
        Car car1=new Car("ki",150,123.44);
        garage.addCar(car);
        garage.addCar(car1);
        List<Car> cars=garage.getCars();
        Assert.assertEquals(cars.size(),garage.getCount());
    }
    @Test
    public void getCount(){
        Car car=new Car("Kiki",280,123.44);
        Car car1=new Car("Ki",150,123.44);
        garage.addCar(car);
        garage.addCar(car1);
        Assert.assertEquals(2,garage.getCount());
    }

    @Test
    public void testAddCar(){
        Car car=new Car("Kiki",280,123.44);
        garage.addCar(car);
        Assert.assertEquals(1,garage.getCount());
    }

    @Test(expected = IllegalArgumentException.class)
    public void testAddCarException(){
        garage.addCar(null);
    }
    @Test
    public void testFindAllCarsWithMaxSpeedAbove(){
        List<Car> cars=garage.findAllCarsWithMaxSpeedAbove(190);
        Assert.assertEquals(2,cars.size());
    }
    @Test
    public void testGetTheMostExpensiveCar(){
        Car car=garage.getTheMostExpensiveCar();
        Assert.assertEquals(toyota,car);
    }
    @Test
    public void testFindAllCarsByBrand(){
        List<Car> cars=garage.findAllCarsByBrand("toyota");
        Assert.assertEquals(2,cars.size());
    }

}