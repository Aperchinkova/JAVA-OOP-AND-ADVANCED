package company;

public class Company {
    private String name;
    private String creationDate;
    private String id;
    public Company(String name, String creationDate, String id) {
        this.name = name;
        setCreationDate(creationDate);
        this.id = id;
    }


    public void setCreationDate(String creationDate) {
        if(creationDate.length()<=10){
            this.creationDate = creationDate;
        }else{
            System.out.println("Invalid data");
        }

    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCreationDate() {
        return creationDate;
    }
}
