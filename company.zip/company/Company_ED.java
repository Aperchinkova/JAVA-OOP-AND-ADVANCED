package company;

public class Company_ED extends Company{


    private String CEO;
    private double initialCapital;
    private double currentCapital;

    public Company_ED(String name, String creationDate, String id,String CEO,double initialCapital,double currentCapital) {
        super(name, creationDate, id);
        this.CEO=CEO;
        this.initialCapital=initialCapital;
        this.currentCapital=currentCapital;
    }
    public String getCEO() {
        return CEO;
    }

    public void setCEO(String CEO) {
        this.CEO = CEO;
    }

    public double getInitialCapital() {
        return initialCapital;
    }

    public void setInitialCapital(double initialCapital) {
        this.initialCapital = initialCapital;
    }

    public double getCurrentCapital() {
        return currentCapital;
    }

    public void setCurrentCapital(double currentCapital) {
        this.currentCapital = currentCapital;
    }

    public double profit(){
        return currentCapital-initialCapital;
    }

}
