package company;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        Company_ED company_ed=new Company_ED("Kamuk EOOD","11.11.20226986868698","1212215634633","Kamuk",1000.0,2000.0);
        System.out.println(company_ed.profit());
    }
}
