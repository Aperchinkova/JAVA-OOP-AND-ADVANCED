package ADVANCED.Google07DefiningClassesExercises;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        String input= scanner.nextLine();
        Map<String,Person> person=new HashMap<>();

        while (!input.equals("End"))
        {
            String[] parts=input.split("\\s+");
            String personName=parts[0];
            if(!person.containsKey(personName))
            {
                person.put(personName,new Person());
            }
            String command=parts[1];
            switch (command) {
                case "company" : {
                    String companyName = parts[2];
                    String department = parts[3];
                    double salary = Double.parseDouble(parts[4]);
                    Company company = new Company(companyName, department, salary);
                    person.get(personName).setCompany(company);
                    break;
                }
                case "pokemon": {
                    String pokemonName = parts[2];
                    String pokemonType = parts[3];
                    Pokemon pokemon = new Pokemon(pokemonName, pokemonType);
                    person.get(personName).getPokemons().add(pokemon);
                    break;
                }
                case "parents" : {
                    String parentName = parts[2];
                    String parentBirthday = parts[3];
                    Parents parents = new Parents(parentName, parentBirthday);
                    person.get(personName).getParents().add(parents);
                    break;
                }
                case "children" : {
                    String childName = parts[2];
                    String childBirthday = parts[3];
                    Children children = new Children(childName, childBirthday);
                    person.get(personName).getChildren().add(children);
                    break;
                }
                case "car" : {
                    String carModel = parts[2];
                    int carSpeed = Integer.parseInt(parts[3]);
                    Car car = new Car(carModel, carSpeed);
                    person.get(personName).setCar(car);
                    break;
                }
            }
            input= scanner.nextLine();
        }
        String name= scanner.nextLine();
        System.out.println(name);
        Person person1=person.get(name);
        System.out.println(person1);
    }
}
