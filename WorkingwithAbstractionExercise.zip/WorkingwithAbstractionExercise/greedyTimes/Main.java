
package WorkingwithAbstractionExercise.greedyTimes;

import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        long capacityOfTheBag = Long.parseLong(scanner.nextLine());

        String[] safe = scanner.nextLine().split("\\s+");

        Map<String, LinkedHashMap<String, Long>>  bag = new LinkedHashMap<>();

        long gold = 0;
        long gems = 0;
        long cash = 0;

        for (int i = 0; i < safe.length; i += 2) {

            String name = safe[i];

            long quantity = Long.parseLong(safe[i + 1]);

            String item = "";

            item = getItem(capacityOfTheBag, bag, name, quantity, item);

            if (item == null) continue;

            if (itemPosition(bag, quantity, item)) continue;

            itemsInTheBag(bag, name, quantity, item);

            if (item.equals("Gold")) {
                gold += quantity;
            } else if (item.equals("Gem")) {
                gems += quantity;
            } else if (item.equals("Cash")) {
               cash += quantity;
            }
        }
        printingSorted(bag);
    }

    private static void printingSorted(Map<String, LinkedHashMap<String, Long>> bag) {
        for (Map.Entry<String, LinkedHashMap<String,Long> > x : bag.entrySet()) {
            Long sumValues = x.getValue().values().stream().mapToLong(l -> l).sum();

            System.out.println(String.format("<%s> $%s", x.getKey(), sumValues));

            x.getValue().entrySet().stream().sorted((e1, e2) -> e2.getKey().compareTo(e1.getKey()))//Print all the types ordered by the total amount in descending order.
                    .forEach(i -> System.out.println("##" + i.getKey() + " - " + i.getValue()));

        }
    }

    private static void itemsInTheBag(Map<String, LinkedHashMap<String, Long>> bag, String name, long quantity, String item) {
        if (!bag.containsKey(item)) {
            bag.put(item, new LinkedHashMap<String, Long>());
        }

        if (!bag.get(item).containsKey(name)) {
            bag.get(item).put(name, 0L);
        }

        //You should aggregate items’ quantities that have the same name.
        bag.get(item).put(name, bag.get(item).get(name) + quantity);
    }

    private static boolean itemPosition(Map<String, LinkedHashMap<String, Long>> bag, long quantity, String item) {
        switch (item) {
            case "Gem":
                //The gold amount in your bag should always be more than or equal to the gem amount at any time
                if (!bag.containsKey(item)) {
                    if (bag.containsKey("Gold")) {
                        if (quantity > bag.get("Gold").values().stream().mapToLong(e -> e).sum()) {
                            return true;
                        }
                    } else {
                        return true;
                    }
                } else if (bag.get(item).values().stream().mapToLong(e -> e).sum() + quantity > bag.get("Gold").values().stream().mapToLong(e -> e).sum()) {
                    return true;
                }
                break;

            case "Cash":
               //The gem amount should always be more than or equal to the cash amount at any time
                if (!bag.containsKey(item)) {
                    if (bag.containsKey("Gem")) {
                        if (quantity > bag.get("Gold").values().stream().mapToLong(e -> e).sum()) {
                            return true;
                        }
                    } else {
                        return true;
                    }
                } else if (bag.get(item).values().stream().mapToLong(e -> e).sum() + quantity > bag.get("Gem").values().stream().mapToLong(e -> e).sum()) {
                    return true;
                }
                break;
        }
        return false;
    }

    private static String getItem(long capacityOfTheBag, Map<String, LinkedHashMap<String, Long>> bag, String name, long quantity, String item) {
        if (name.length() == 3) {//Cash - All three letter items
            item = "Cash";//Reading item’s names should be CASE-INSENSITIVE, except when the item is Cash.
        } else if (name.toLowerCase().endsWith("gem")) {//Gem - All items which end on "Gem" (at least 4 symbols)
            item = "Gem";//Reading item’s names should be CASE-INSENSITIVE, except when the item is Cash.
        } else if (name.toLowerCase().equals("gold")) {
            item = "Gold";//Reading item’s names should be CASE-INSENSITIVE, except when the item is Cash.
        }

        if (item.equals("")) {//Each item that does not fall in one of the above categories is useless and you should skip it
            return null;
        } //You should always be careful not to exceed the overall bag’s capacity because it will tear down and you will lose everything!
        else if (capacityOfTheBag < bag.values().stream().map(Map::values).flatMap(Collection::stream).mapToLong(e -> e).sum() + quantity) {
            return null;
        }
        return item;
    }
}