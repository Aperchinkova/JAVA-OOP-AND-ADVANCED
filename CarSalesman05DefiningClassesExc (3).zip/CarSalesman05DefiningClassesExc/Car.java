package CarSalesman05DefiningClassesExc;

public class Car {
    private String model;
    private Engine engine;
    //optional
    private int weight;
    private String color;

    public Car(String model,Engine engine)
    {
        this.model=model;
        this.engine=engine;
        this.weight=0;
        this.color="n/a";
    }

    public Car(String model,Engine engine,int weight,String color)
    {
        this(model,engine);
        this.weight=weight;
        this.color=color;
    }

    public Car(String model,Engine engine,String color)
    {
        this(model,engine);
        this.color=color;
    }
    public Car(String model,Engine engine,int weight)
    {
        this(model,engine);
        this.weight=weight;
    }
    @Override
    public String toString()
    {
        String weightPrint;
        if(weight==0)
        {
            weightPrint="n/a";
        }else{
            weightPrint=weight+"";
        }
        StringBuilder sb=new StringBuilder();
        sb.append(model).append(":").append("\n")
                .append(engine.toString())
                .append("Weight: ").append(weightPrint).append("\n")
                .append("Color: ").append(color);
        return sb.toString();
    }
}
