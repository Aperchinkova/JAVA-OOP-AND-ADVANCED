package CarSalesman05DefiningClassesExc;

import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        int n=Integer.parseInt(scanner.nextLine());

        Map<String,Engine> engines=new HashMap<>();
        for(int i=0;i<n;i++)
        {
            String[] input=scanner.nextLine().split("\\s+");

            String model=input[0];
            int enginePower=Integer.parseInt(input[1]);
            Engine engine=null;
            if(input.length==2)
            {
                engine=new Engine(model,enginePower);
            }else if(input.length==4)
            {
                int engineDisplacement=Integer.parseInt(input[2]);
                String engineEfficiency=input[3];
                engine=new Engine(model,enginePower,engineDisplacement,engineEfficiency);
            }else if(input.length==3)
            {
                try{
                    int engineDisplacement=Integer.parseInt(input[2]);
                    engine=new Engine(model,enginePower,engineDisplacement);
                }catch (NumberFormatException e)
                {
                    String engineEfficiency=input[2];
                    engine=new Engine(model,enginePower,engineEfficiency);
                }
            }
            engines.put(model,engine);

        }

        List<Car> cars=new ArrayList<>();
        int m=Integer.parseInt(scanner.nextLine());
        for(int i=0;i<m;i++)
        {
            String[] carParts=scanner.nextLine().split("\\s+");
            String model=carParts[0];
            String engineModel=carParts[1];
            Engine carEngine=engines.get(engineModel);//obekt ot tip dvigate;
            Car car=null;
            if(carParts.length==2)
            {
                car=new Car(model,carEngine);
            }
            else if(carParts.length==4)
            {
                int weight=Integer.parseInt(carParts[2]);
                String color=carParts[3];
                car=new Car(model,carEngine,weight,color);
            }else{
                try{
                    int weight=Integer.parseInt(carParts[2]);
                    car=new Car(model,carEngine,weight);
                }catch (NumberFormatException e)
                {
                    String color=carParts[2];
                    car=new Car(model,carEngine,color);
                }
            }
            cars.add(car);
        }
        for(Car car:cars)
        {
            System.out.println(car.toString());
        }
    }
}
