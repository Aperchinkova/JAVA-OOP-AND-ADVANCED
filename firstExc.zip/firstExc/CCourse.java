package firstExc;

import java.util.List;
import java.util.Map;

public class CCourse {


    private String name;

    private List<Double> scores;
    private String fn;

    protected Map<String,Double> fnScores;

    public CCourse(String name,List<Double> scores, String fn) {
        this.name = name;
        this.scores = scores;
        this.fn = fn;
    }
    public double getGrade(List<Double> scores){
        double sum=0;
        for(double s:scores){
            sum+=s;
        }
        return sum/scores.size();
    }
    public void addScore(double score,List<Double> scores){
        scores.add(score);
    }

    /*
    public void createMap(int n,String fn,List<Double> scores){
        Map<String,Double> fnScores=n;
        for(int i=0;i<n;i++){
            fnScores.put(fn,scores);
        }
    }

     */
}
