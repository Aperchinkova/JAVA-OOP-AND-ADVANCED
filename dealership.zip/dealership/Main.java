package dealership;

public class Main {

    public static void main(String[] args) {
        Car car=new Car("BMW","X5",2018);
        Car car1=new Car("Shkoda","99",2019);
        Car car2=new Car("Audi","A3",2022);
        Dealership dealership=new Dealership("Mobile",2);
        String caradd=car.toString();
        dealership.add(car);
        dealership.add(car1);
        dealership.add(car2);
      //  System.out.println(dealership.buy("BMW","X5"));
       // System.out.println(dealership.getCar("Shkoda","99"));
      // System.out.println(dealership.getCount());
        System.out.println(dealership.getStatistics());
    }
}
