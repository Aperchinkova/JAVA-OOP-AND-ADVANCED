package BirthdayCelebrations;

import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        String command=scanner.nextLine();
        /*
        Map<Citizen,String> c=new LinkedHashMap<>();
        Map<Pet,String> p=new LinkedHashMap<>();

         */
        List<Birthable> list=new ArrayList<>();
        while (!command.equals("End")){
            String[] input=command.split("\\s+");
            if(input.length==5){
                Citizen citizen=new Citizen(input[1],Integer.parseInt(input[2]),input[3],input[4]);
                list.add(citizen);
            }else if(input.length==3){
                Pet pet=new Pet(input[1],input[2]);
                list.add(pet);
            }
            command=scanner.nextLine();
        }
        String year=scanner.nextLine();
       list.stream().map(Birthable::getBirthDate).filter(birthDate->birthDate.endsWith(year)).forEach(System.out::println);
    }
}
