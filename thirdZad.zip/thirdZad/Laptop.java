package thirdZad;

public class Laptop extends ElectricalDevice{

    private int RAM;
    private int hardDisk;

    public Laptop(int poweringU, String modelType,int RAM,int hardDisk) {
        super(poweringU, modelType);
        this.RAM=RAM;
        this.hardDisk=hardDisk;
    }
    public int getRAM() {
        return RAM;
    }

    public void setRAM(int RAM) {
        this.RAM = RAM;
    }

    public int getHardDisk() {
        return hardDisk;
    }

    public void setHardDisk(int hardDisk) {
        this.hardDisk = hardDisk;
    }
    public boolean isBetter(Laptop laptop){
        if(this.RAM > laptop.getRAM() && this.hardDisk>laptop.getHardDisk()){
            return true;
        }else{
            return false;
        }
    }

    @Override
    public String toString() {
        return String.format("Powering : %d,Processor type: %s,RAM: %d,HardDisk:%d",getPoweringU(),getModelType(),RAM,hardDisk);
    }
}
