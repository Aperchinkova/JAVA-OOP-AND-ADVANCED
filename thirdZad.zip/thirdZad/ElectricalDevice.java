package thirdZad;

public class ElectricalDevice {
    private int poweringU;
    private String modelType;

    public ElectricalDevice(int poweringU, String modelType) {
        this.poweringU = poweringU;
        this.modelType = modelType;
    }

    public int getPoweringU() {
        return poweringU;
    }

    public void setPoweringU(int poweringU) {
        this.poweringU = poweringU;
    }

    public String getModelType() {
        return modelType;
    }

    public void setModelType(String modelType) {
        this.modelType = modelType;
    }
    public void on(){
        System.out.println("The device is on");
    }
    public void off(){
        System.out.println("The device is off");
    }
}
