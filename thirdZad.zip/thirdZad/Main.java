package thirdZad;

public class Main {
    public static void main(String[] args) {
        Laptop laptop1=new Laptop(12,"Intel",256,64);
        laptop1.on();
        System.out.println(laptop1.toString());
        Laptop laptop2=new Laptop(15,"Amd",512,99);
        laptop2.on();
        System.out.println(laptop2.toString());
        System.out.println(laptop1.isBetter(laptop2));
        System.out.println(laptop2.isBetter(laptop1));
        laptop1.off();
        laptop2.off();
    }
}
