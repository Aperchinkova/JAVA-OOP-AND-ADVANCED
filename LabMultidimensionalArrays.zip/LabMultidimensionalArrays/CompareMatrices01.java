package ADVANCED.LabMultidimensionalArrays;

import java.util.Arrays;
import java.util.Scanner;

public class CompareMatrices01 {
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        String[] nums=scanner.nextLine().split("\\s+");
        int rows=Integer.parseInt(nums[0]);
        int cols=Integer.parseInt(nums[1]);
        int[][] firstMatrix=new int[rows][cols];
        for(int row=0;row<rows;row++)
        {
            String[] input=scanner.nextLine().split("\\s+");
            for(int col=0;col<cols;col++)
            {
                firstMatrix[row][col]=Integer.parseInt(input[col]);
            }
        }
        String[] nums2=scanner.nextLine().split("\\s+");
        int rows2=Integer.parseInt(nums2[0]);
        int cols2=Integer.parseInt(nums2[1]);
        int[][] secondMatrix=new int[rows2][cols2];
        if(rows!=rows2||cols!=cols2)
        {
            System.out.println("not equal");
            return;
        }
        for(int row=0;row<rows2;row++)
        {
            String[] input=scanner.nextLine().split("\\s+");

            for(int col=0;col<cols;col++)
            {
                secondMatrix[row][col]=Integer.parseInt(input[col]);
            }
        }
        boolean equal=false;
        for(int i=0;i<rows;i++)
        {
            for(int j=0;j<cols2;j++)
            {
                if(firstMatrix[i][j]!=secondMatrix[i][j])
                {
                    System.out.println("not equal");
                    equal=true;
                    return;
                }
            }
        }
        System.out.println("equal");

    }
}
