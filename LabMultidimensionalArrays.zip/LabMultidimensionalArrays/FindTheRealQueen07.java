package ADVANCED.LabMultidimensionalArrays;

import java.util.Scanner;

public class FindTheRealQueen07 {
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        int rows=8;
        int cols=8;
        char[][] matrix=new char[rows][cols];
        for(int row=0;row<rows;row++)
        {
            String[] line=scanner.nextLine().split("\\s+");
            for(int col=0;col<cols;col++)
            {
                char currentChar=line[col].charAt(0);
                matrix[row][col]=currentChar;
            }
        }
        for(int i=0;i<rows;i++)
        {
            for(int j=0;j<cols;j++)
            {
                if(matrix[i][j]=='q'&&isValidQueen(i,j,matrix)){
                    System.out.println(i+" "+j);
                }

            }
        }
    }

    private static boolean isValidQueen(int row, int col, char[][] matrix) {
        for (int rowDirection = -1; rowDirection <= 1; rowDirection++) {
            for (int colDirection = -1; colDirection <= 1; colDirection++) {
                if (rowDirection == 0 && colDirection == 0) {
                    continue;
                }
                int currentRow = row + rowDirection;
                int currentCol = col + colDirection;
                boolean validPosition = isValidPosition(matrix, currentRow, currentCol);
                while (validPosition) {
                    if ('q' == matrix[currentRow][currentCol]) {
                        return false;
                    }
                    currentRow = currentRow + rowDirection;
                    currentCol = currentCol + colDirection;
                    validPosition = isValidPosition(matrix, currentRow, currentCol);
                }
            }
        }
        return true;
    }

    private static boolean isValidPosition(char[][] matrix, int currentRow, int currentCol) {
        return currentRow>=0
                && currentRow< matrix.length
                && currentCol>=0
                && currentCol<matrix[currentRow].length;
    }

}
