package ADVANCED.LabMultidimensionalArrays;

import java.util.Scanner;

public class SumMatrixElements04 {
    public static void main(String[] args) {
        Scanner scanner=new Scanner( System.in);
        String[] input=scanner.nextLine().split(", ");
        int row=Integer.parseInt(input[0]);
        int cols=Integer.parseInt(input[1]);
        int[][] matrix=new int[row][cols];
        int sum=0;
        for(int i=0;i<row;i++)
        {
            String[] numbers=scanner.nextLine().split(", ");
            for(int j=0;j<cols;j++)
            {
                matrix[i][j]=Integer.parseInt(numbers[j]);
                sum+=matrix[i][j];
            }
        }
        System.out.println(row);
        System.out.println(cols);
        System.out.println(sum);
    }
}
