package ADVANCED.LabMultidimensionalArrays;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Scanner;

public class MaximumSumof2x2Submatrix05 {
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        String[] input=scanner.nextLine().split(", ");
        int row=Integer.parseInt(input[0]);
        int cols=Integer.parseInt(input[1]);
        int[][] matrix=new int[row][cols];
        for(int i=0;i<row;i++)
        {
            String[] numbers=scanner.nextLine().split(", ");
            for(int j=0;j<cols;j++)
            {
                matrix[i][j]=Integer.parseInt(numbers[j]);
            }
        }
        int sum=0;
        int currentsum=0;
        String[] numbers=new String[4];
        for(int i =0;i<row-1;i++)
        {
            int count=0;
            for (int j=0;j<cols-1;j++)
            {


                currentsum+=matrix[i][j]+matrix[i][j+1]+matrix[i+1][j]+matrix[i+1][j+1];
                if(currentsum>sum)
                {

                    sum=currentsum;
                    numbers[0]=matrix[i][j]+"";
                    numbers[1]=matrix[i][j+1]+"";
                    numbers[2]=matrix[i+1][j]+"";
                    numbers[3]=matrix[i+1][j+1]+"";
                }
                currentsum=0;
            }
        }
        System.out.println(numbers[0]+" "+numbers[1]);
        System.out.println(numbers[2]+" "+numbers[3]);
        System.out.println(sum);
    }
}
