package first;

public interface IsSeaVessel {
    void enterSea();

}
