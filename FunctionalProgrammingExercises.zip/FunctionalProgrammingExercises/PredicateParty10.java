package ADVANCED.FunctionalProgrammingExercises;

import java.util.*;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public class PredicateParty10 {
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        List<String> list= Arrays.stream(scanner.nextLine().split("\\s+")).collect(Collectors.toList());
        String commands= scanner.nextLine();
        while (!commands.equals("Party!"))
        {
            String[] parts=commands.split("\\s+");
            String command=parts[0];

            Predicate<String> predicate=getPredicate(parts);
            switch (command)
            {
                case "Remove":
                    list.removeIf(predicate);

                    break;
                case "Double":

                    List<String> peopleToAddAgain=new ArrayList<>();
                  //  list.stream().filter(predicate).forEach(e->addagain.add(e));
                    list.stream().filter(predicate).forEach(person->peopleToAddAgain.add(person));
                    list.addAll(peopleToAddAgain);
                    break;
            }
            commands=scanner.nextLine();
        }
        if(list.isEmpty())
        {
            System.out.println("Nobody is going to the party!");
        }else{
            Collections.sort(list);
            String st=String.join(", ",list)+" are going to the party!";
            System.out.println(st);
        }
    }

    public static Predicate<String> getPredicate(String[] parts) {
        Predicate<String> predicate=null;
        String filterName = parts[1];
        String filterCriteria = parts[2];
        switch (filterName) {
            case "StartsWith":
                predicate =name -> name.startsWith(filterCriteria);
                break;
            case "EndsWith":
                //predicate = name -> name.endsWith(filterCriteria);
                predicate=name->name.endsWith(filterCriteria);
                break;
            case "Length":
                predicate = name -> name.length() == Integer.parseInt(filterCriteria);
                break;
        }
        return predicate;
    }
}
