package ADVANCED.FunctionalProgrammingExercises;

import java.util.Arrays;
import java.util.Scanner;
import java.util.function.Consumer;

public class ConsumerPrint01 {
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        String[] input=scanner.nextLine().split("\\s+");
        Consumer<String> printing=e-> System.out.println(e);
        //1.way
        //Arrays.stream(input).forEach(printing);
        //2.way
        /*
        for(String s:input)
        {
            printing.accept(s);
        }

         */
        //3.way
        /*
        for(String s:input)
        {
            System.out.println(s);
        }

         */
        Consumer<String[]> printNames=array->{
            for(String name:array)
            {
                System.out.println(name);
            }
        };
        printNames.accept(input);
    }
}
