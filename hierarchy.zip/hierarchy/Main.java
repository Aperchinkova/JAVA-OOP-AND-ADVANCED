package hierarchy;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);

        List<Animal> animals=new ArrayList<>();
        String command=scanner.nextLine();
        while (!command.equals("End")){
            String[] input=command.split("\\s+");
            Animal animal=createAnimal(input);
            String foodInput=scanner.nextLine();
            Food food=getFood(foodInput.split("\\s+"));
            animal.makeSound();
            try
            {
                animal.eatFood(food);
            }catch (IllegalArgumentException ex){
                System.out.println(ex.getMessage());
            }
            animals.add(animal);
            command=scanner.nextLine();
        }
        animals.forEach(System.out::println);

    }
    public static Food getFood(String[] input){
        String type=input[0];
        int quantity=Integer.parseInt(input[1]);
        if(type.equals("Meat")){
            return new Meat(quantity);
        }else{
            return new Vegetable(quantity);
        }
    }
    public static Animal createAnimal(String[] input){
        String type=input[0];
        String name=input[1];
        double weight=Double.parseDouble(input[2]);
        String livingRegion=input[3];
        switch (type){
            case "Cat":
                return new Cat(name,type,weight,livingRegion,input[4]);

            case "Mouse":
                return new Mouse(name,type,weight,livingRegion);

            case "Zebra":
                return new Zebra(name,type,weight,livingRegion);

            case "Tiger":
                return new Tiger(name,type,weight,livingRegion);

            default:
                throw new IllegalArgumentException("No such animal");
        }
    }
}
