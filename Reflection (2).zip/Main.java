import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.Comparator;

public class Main {
    public static void main(String[] args) {
        Class<Reflection> clazz= Reflection.class;

        /*
        System.out.println(clazz);
        System.out.println(clazz.getSuperclass());
        Class[] interfaces=clazz.getInterfaces();
        Arrays.stream(interfaces).forEach(System.out::println);
        Reflection ref= (Reflection) clazz.getDeclaredConstructor().newInstance();
         Reflection ref= (Reflection) clazz.newInstance();
        System.out.println(ref);
        Constructor ref=clazz.getDeclaredConstructor();
        System.out.println(ref);
         */



        Method[] methods=clazz.getDeclaredMethods();

        Arrays.stream(methods)
                .filter(method -> method.getName().startsWith("get") && method.getParameterCount()==0)
                .sorted(Comparator.comparing(Method::getName))
                .forEach(method -> System.out.printf("%s will return class %s%n",method.getName(),method.getReturnType().getSimpleName()));
        Arrays.stream(methods)
                .filter(method -> method.getName().startsWith("set") && method.getParameterCount()==1)
                .sorted(Comparator.comparing(Method::getName))
                .forEach(method -> System.out.printf("%s and will set field of class %s%n",method.getName(),method.getParameterTypes()[0].getSimpleName()));



        // int modifiers=clazz.getModifiers();
        /*
        int modifiers=clazz.getModifiers();
        Field[] fields= clazz.getDeclaredFields();
        for(Field field:fields){

            if(!Modifier.isPrivate(field.getModifiers())){
                System.out.printf("%s must be private!%n",field.getName());
            }
        }

        Method[] methods= clazz.getDeclaredMethods();
        Arrays.stream(methods).sorted(Comparator.comparing(Method::getName));
        for(Method method:methods){
            if(!Modifier.isPublic(method.getModifiers()) && method.getName().startsWith("get")){

                System.out.printf("%s have to be public!%n",method.getName());
            }
        }
        for(Method method:methods){
            if(!Modifier.isPrivate(method.getModifiers()) && method.getName().startsWith("set")){
                System.out.printf("%s have to be private!%n",method.getName());
            }
        }

         */
    }
}
