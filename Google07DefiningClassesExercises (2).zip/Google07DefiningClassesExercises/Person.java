package Google07DefiningClassesExercises;

import java.util.ArrayList;
import java.util.List;

public class Person {
    private Company company;
    private List<Pokemon> pokemons;
    private List<Parents> parents;
    private List<Children> children;
    private Car car;
    public void setCar(Car car) {
        this.car = car;
    }



    public List<Parents> getParents() {
        return parents;
    }

    public List<Children> getChildren() {
        return children;
    }


    public List<Pokemon> getPokemons() {
        return pokemons;
    }


    public Person(Company company, List<Pokemon> pokemons, List<Parents> parents, List<Children> children, Car car) {
        this.company = company;
        this.pokemons = pokemons;
        this.parents = parents;
        this.children = children;
        this.car = car;
    }
    public Person()
    {
        this.company=null;
        this.car=null;
        this.pokemons=new ArrayList<>();
        this.children=new ArrayList<>();
        this.parents=new ArrayList<>();

    }


    public void setCompany(Company company) {
        this.company=company;
    }
    @Override
    public String toString()
    {
        StringBuilder sb=new StringBuilder();
        sb.append("Company:").append("\n");
        if(company!=null) {
            sb.append(company).append("\n");
        }
        sb.append("Car:").append("\n");
        if(car!=null){
            sb.append(car).append("\n");
        }
        sb.append("Pokemon:").append("\n");
        for(Pokemon pokemon:pokemons){
             sb.append(pokemon).append("\n");
        }
        sb.append("Parents:").append("\n");
        for(Parents parents:parents)
        {
            sb.append(parents).append("\n");
        }
        sb.append("Children:").append("\n");
        for(Children children:children)
        {
            sb.append(children).append("\n");
        }

        return sb.toString();
    }
}
