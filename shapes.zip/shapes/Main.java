package shapes;

public class Main {
    public static void main(String[] args) {
        Shape circle=new Circle(3.0);
        System.out.println(circle.calculateArea());
        System.out.println(circle.calculatePerimeter());
        Shape rectangle=new Rectangle(2.0,3.0);
        System.out.println(rectangle.calculatePerimeter());
        System.out.println(rectangle.calculateArea());
    }
}
