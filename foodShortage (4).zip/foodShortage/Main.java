package foodShortage;

import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        int n=Integer.parseInt(scanner.nextLine());

        List<Citizen> c=new ArrayList<>();
        List<Rebel> r=new ArrayList<>();
        for(int i=0;i<n;i++){
            String[] input=scanner.nextLine().split("\\s+");
            if(input.length==4){
                Citizen citizen=new Citizen(input[0],Integer.parseInt(input[1]),input[2],input[3]);
                c.add(citizen);
            }else if(input.length==3){
                Rebel rebel=new Rebel(input[0],Integer.parseInt(input[1]),input[2]);
                r.add(rebel);
            }
        }
        String names=scanner.nextLine();

        while (!names.equals("End")){
            String name=names;
            c.stream().filter(citizen->citizen.getName().equals(name))
                    .findFirst().ifPresent(Citizen::buyFood);
            r.stream().filter(rebel -> rebel.getName().equals(name))
                    .findFirst().ifPresent(Rebel::buyFood);
            names=scanner.nextLine();
        }
        System.out.println(c.stream().map(Citizen::getFood)
                .reduce(0, Integer::sum) + r.stream().map(Rebel::getFood)
                .reduce(0, Integer::sum));
        scanner.close();
    }
}
