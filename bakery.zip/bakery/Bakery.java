package bakery;

import java.util.ArrayList;
import java.util.List;

public class Bakery {
    public List<Employee> employees;
    private String name;
    private int capacity;

    public Bakery(String name, int capacity) {
        this.name = name;
        this.capacity = capacity;
        this.employees=new ArrayList<>();
    }
    public void add(Employee employee){
        if(employees.size()<capacity){
            employees.add(employee);
        }
    }
    public boolean remove(String name){
        for(Employee employee:employees){
            if(employee.getName().equals(name)){
                return true;
            }
        }
        return false;
    }
    public Employee getOldestEmployee(){
        int old=Integer.MIN_VALUE;
        Employee employee=null;

        for(Employee employee1:employees){
            if(employee1.getAge()>old){
                old= employee1.getAge();
                employee=employee1;
            }
        }
        return employee;
    }
    public Employee getEmployee(String name){
        Employee employee=null;
        for(Employee employee1:employees){
            if(employee1.getName().equals(name)){
                employee=employee1;
            }
        }
        return employee;
    }
    public int getCount(){
        return employees.size();
    }
    public String report(){
        StringBuilder sb=new StringBuilder();
        sb.append("Employees working at Bakery "+this.name+":").append(System.lineSeparator());
        for(Employee employee:employees){
            sb.append(employee.toString()).append(System.lineSeparator());
        }
        return sb.toString();
    }

}
