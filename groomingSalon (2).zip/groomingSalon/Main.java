package groomingSalon;

public class Main {

    public static void main(String[] args) {
	// write your code here
        Pet pet=new Pet("Kaya",4,"Aya");
        Pet pet1=new Pet("Dzhansu",2,"Mama");
        GroomingSalon groomingSalon=new GroomingSalon(3);
        groomingSalon.add(pet);
        groomingSalon.add(pet1);
        System.out.println(groomingSalon.remove("Kaya"));
        System.out.println(groomingSalon.getPet("Dzhansu","Mama"));
        System.out.println(groomingSalon.getCount());
        System.out.println(groomingSalon.getStatistics());
    }
}
