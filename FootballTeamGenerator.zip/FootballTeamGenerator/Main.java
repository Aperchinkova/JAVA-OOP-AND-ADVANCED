package FootballTeamGenerator;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);

        String line= scanner.nextLine();
        Map<String,Team> teams=new LinkedHashMap<>();

        while (!line.equals("END")){

            String[] commandParts=line.split(";");
            String command=commandParts[0];
            String name=commandParts[1];

            try{
                switch (command){

                    case "Team":
                        Team team=new Team(name);
                        teams.putIfAbsent(name,team);
                        break;

                    case "Add":

                        String playerName=commandParts[2];
                        int endurance=Integer.parseInt(commandParts[3]);
                        int sprint = Integer.parseInt(commandParts[4]);
                        int dribble = Integer.parseInt(commandParts[5]);
                        int passing = Integer.parseInt(commandParts[6]);
                        int shooting = Integer.parseInt(commandParts[7]);

                        if(!teams.containsKey(name)){
                            System.out.printf("Team %s does not exist.%n", name);
                        }else{
                            Player player=new Player(playerName,endurance,sprint,dribble,passing,shooting);
                            teams.get(name).addPlayer(player);
                        }
                        break;
                    case "Remove":
                        String playerToRemove=commandParts[2];
                        teams.get(name).removePlayer(playerToRemove);
                        break;
                    case "Rating":
                        if(!teams.containsKey(name)){
                            System.out.printf("Team %s does not exist.%n", name);
                        }else{
                            System.out.printf("%s - %d%n",name,Math.round(teams.get(name).getRating()));
                        }
                        break;
                }
            }catch (IllegalArgumentException e){
                System.out.println(e.getMessage());
            }

            command= scanner.nextLine();
        }
    }
}
