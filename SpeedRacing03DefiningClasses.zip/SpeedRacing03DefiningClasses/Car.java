package SpeedRacing03DefiningClasses;

public class Car {
    private String model;
    private double fuelAmount;
    private double fuelCostFor1km;
    private int distanceTravelled=0;

    public void setModel(String model) {
        this.model = model;
    }

    public void setFuelAmount(double fuelAmount) {
        this.fuelAmount = fuelAmount;
    }

    public void setFuelCostFor1km(double fuelCostFor1km) {
        this.fuelCostFor1km = fuelCostFor1km;
    }

    public void setDistanceTravelled(int distanceTravelled) {
        this.distanceTravelled = distanceTravelled;
    }


    public String getModel() {
        return model;
    }

    public double getFuelAmount() {
        return fuelAmount;
    }

    public double getFuelCostFor1km() {
        return fuelCostFor1km;
    }

    public double getDistanceTravelled() {
        return distanceTravelled;
    }


    public Car(String model,double fuelAmount,double fuelCostFor1km)
    {
        this.model=model;
        this.fuelAmount=fuelAmount;
        this.fuelCostFor1km=fuelCostFor1km;
       // this.distanceTravelled=distanceTravelled;
    }
    public boolean hasEnoughFuel(int amountOfKm){

        double fuelNeeded=calculateNeededFuel(amountOfKm);
        return fuelAmount>=fuelNeeded;
    }
    public double calculateNeededFuel(int amountOfKm)
    {
        return amountOfKm*fuelCostFor1km;
    }
    public void drive(int amountOfKm)
    {
        double fuelNeeded=calculateNeededFuel(amountOfKm);
        fuelAmount-=fuelNeeded;
        distanceTravelled+=amountOfKm;
    }

    @Override
    public String toString() {
      //  return model+" "+String.format("%.2f",this.fuelAmount+" ")+distanceTravelled;
        return String.format("%s %.2f %d",this.model,this.fuelAmount,this.distanceTravelled);
    }
}
