package SpeedRacing03DefiningClasses;

import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        int n=Integer.parseInt(scanner.nextLine());
      //  Map<>
        Map<String,Car> map=new LinkedHashMap<>();
        for(int i=0;i<n;i++)
        {
            String[] input=scanner.nextLine().split("\\s+");

            String model=input[0];
            double fuelAmount=Double.parseDouble(input[1]);
            double fuelCostFor1km=Double.parseDouble(input[2]);
            Car car=new Car(model,fuelAmount,fuelCostFor1km);
            map.put(model,car);
        }
        String command=scanner.nextLine();
        while (!command.equals("End"))
        {
            String[] parts=command.split("\\s+");
            String carModel=parts[1];
            int amountOfKm=Integer.parseInt(parts[2]);
            Car currentCar=map.get(carModel);
            if(!currentCar.hasEnoughFuel(amountOfKm))
            {
                System.out.println("Insufficient fuel for the drive");
            }else{
                currentCar.drive(amountOfKm);
            }
            command= scanner.nextLine();
        }
        for(Car car:map.values())
        {
            System.out.println(car.toString());
        }

    }
}
