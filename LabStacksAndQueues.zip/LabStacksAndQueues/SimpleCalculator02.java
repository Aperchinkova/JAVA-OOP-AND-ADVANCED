package ADVANCED.LabStacksAndQueues;

import java.awt.*;
import java.util.ArrayDeque;
import java.util.Arrays;
import java.util.Collections;
import java.util.Scanner;

public class SimpleCalculator02 {
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        /*
        String[] expression=scanner.nextLine().split("\\s+");
        ArrayDeque<String> stack=new ArrayDeque<>();
        for(int i=expression.length-1;i>=0;i--)
        {
            stack.push(expression[i]);
        }
        while (stack.size()>1)
        {
            int left=Integer.parseInt(stack.pop());
            String operant=stack.pop();
            int right=Integer.parseInt(stack.pop());
            int result=operant.equals("+")
                    ? left+right
                    : left-right;
            stack.push(String.valueOf(result));
        }
        System.out.println(stack.pop());

         */
        String[] input=scanner.nextLine().split("\\s+");
        ArrayDeque<String> tokens=new ArrayDeque<>();
        Collections.addAll(tokens,input);
        while (tokens.size()>1)
        {
            int first=Integer.parseInt(tokens.pop());
            String op=tokens.pop();
            int second=Integer.parseInt(tokens.pop());
            int result=0;
            if(op.equals("+"))
            {
                result=first+second;
            }else{
                result=first-second;
            }
            tokens.push(String.valueOf(result));
        }
        System.out.println(tokens.peek());
    }
}
