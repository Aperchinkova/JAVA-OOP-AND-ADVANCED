package ADVANCED.LabStacksAndQueues;

import java.util.ArrayDeque;
import java.util.Scanner;

public class MatchingBrackets04 {
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        String exp= scanner.nextLine();
        ArrayDeque<Integer> stack=new ArrayDeque<>();
        for(int i=0;i<exp.length();i++)
        {
            char symbol=exp.charAt(i);
            if(symbol=='(')
            {
                stack.push(i);
            }
            if(symbol==')')
            {
                int startIndex=stack.pop();
                String contents=exp.substring(startIndex,i+1);
                System.out.println(contents);
            }
        }
    }
}
