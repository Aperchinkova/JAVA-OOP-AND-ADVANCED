package ADVANCED.LabStacksAndQueues;

import java.util.ArrayDeque;
import java.util.Scanner;

public class MathPotato07 {
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        String[] names=scanner.nextLine().split("\\s+");
        int num=Integer.parseInt(scanner.nextLine());
        ArrayDeque<String> queue=new ArrayDeque<>();
        for(int i=0;i<names.length;i++)
        {
            queue.offer(names[i]);
        }
        /*
        int cycles=1;

        while(queue.size()>1)
        {
            for(int i=1;i<num;i++)
            {
                String currentChild=queue.poll();
                queue.offer(currentChild);
            }
            String name=queue.peek();
            if(isPrime(cycles)==false)
            {
                String childName=queue.poll();
                System.out.println("Removed "+childName);
            }else{
                System.out.println("Prime "+name);
            }
            cycles++;
        }

        String lastChild=queue.peek();
        System.out.println("Last is "+ lastChild);

         */
        int cycles=1;
        while(queue.size()>1)
        {
            for(int i=1;i<num;i++)
            {
                String name=queue.poll();
                queue.offer(name);
            }
            String childName=queue.peek();
            if(isPrime(cycles)==false)//ako e prime go mahame
            {
                String child=queue.poll();
                System.out.println("Removed "+child);
            }else
            {
                System.out.println("Prime "+childName);
            }
            cycles++;
        }
        System.out.println("Last is "+queue.peek());

    }
    private static boolean isPrime(int numeber)
    {
        if(numeber==1)
        {
            return false;//prime e
        }
        for(int i=2;i<numeber;i++)
        {
            if(numeber%i==0)
            {
                return false;//prime e
            }
        }
        return true;
    }

    /*
    private static boolean isPrime(int number)
    {
        if(number==1)
        {
            return false;
        }
        for (int i=2;i<number;i++)
        {
            if(number%i==0){
                return false;
            }
        }
        return true;
    }

     */
}
