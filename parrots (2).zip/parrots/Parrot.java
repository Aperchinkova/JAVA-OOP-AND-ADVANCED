package parrots;

public class Parrot {
    private boolean available;
    private String species;
    private String name;

    public boolean isAvailable() {
        return available;
    }

    public String getName() {
        return name;
    }
    public String getSpecies() {
        return species;
    }
    public void setAvailable(boolean available) {
        this.available = available;
    }

    public Parrot(String name, String species) {
        this.name = name;
        this.species = species;
        this.available=true;
    }
    @Override
    public String toString(){
        StringBuilder sb=new StringBuilder();
        sb.append("Parrot (").append(this.species).append("): ").append(this.name);
        return sb.toString();
    }

}
