package parrots;

import java.util.ArrayList;
import java.util.List;

public class Cage {
    public List<Parrot> data;
    private String name;
    private int capacity;

    public String getName() {
        return name;
    }

    public int getCapacity() {
        return capacity;
    }

    public Cage(String name, int capacity) {
        this.name = name;
        this.capacity = capacity;
        this.data=new ArrayList<>();
    }
    public void add(Parrot parrot){
        if(this.data.size()<capacity){
            data.add(parrot);
        }
    }
    public boolean remove(String name) {
        for (int i = 0; i < this.data.size(); i++) {
            if (this.data.get(i).getName().equals(name)) {
                this.data.remove(i);
                return true;
            }
        }
        return false;
    }
    public Parrot sellParrot(String name){
        Parrot parrot1=null;
        for(Parrot parrot:this.data){
            if(parrot.getName().equals(name)){
                parrot.setAvailable(false);
                parrot1=parrot;
            }
        }
        return parrot1;
    }
    public List<Parrot> sellParrotBySpecies(String species){
        List<Parrot> parrots=new ArrayList<>();
        for(Parrot parrot:data){
            if(parrot.getSpecies().equals(species)){
                parrot.setAvailable(false);
                parrots.add(parrot);
            }
        }
        return parrots;
    }

    public int count(){
        return data.size();
    }
    public String report(){
        StringBuilder sb=new StringBuilder();
        sb.append(String.format("Parrots available at %s:",this.name)).append(System.lineSeparator());
        for(Parrot parrot:this.data){
            if(parrot.isAvailable()){
                sb.append(parrot.toString()).append(System.lineSeparator());
            }
        }
        return sb.toString().trim();
    }

}
