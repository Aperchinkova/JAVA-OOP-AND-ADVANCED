package ADVANCED.SetsAndMapsAdvancedLab;

import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

public class Voina03 {
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        LinkedHashSet<Integer> firstPlayer= Arrays.stream(scanner.nextLine().split(" "))
                .map(Integer::parseInt).collect(Collectors.toCollection(LinkedHashSet::new));
        LinkedHashSet<Integer> secondPlayer= Arrays.stream(scanner.nextLine().split(" "))
                .map(Integer::parseInt).collect(Collectors.toCollection(LinkedHashSet::new));
        for(int i=0;i<50;i++)
        {
            if(firstPlayer.isEmpty())
            {
                break;
            }else if(secondPlayer.isEmpty())
            {
                break;
            }
            int first=firstPlayer.iterator().next();
            int second=secondPlayer.iterator().next();
            firstPlayer.remove(first);
            secondPlayer.remove(second);
            if(first>second)
            {
                firstPlayer.add(first);
                firstPlayer.add(second);
            }else if(second>first)
            {
                secondPlayer.add(first);
                secondPlayer.add(second);
            }
        }
        if(firstPlayer.size()< secondPlayer.size())
        {
            System.out.println("Second player win!");
        }else if(firstPlayer.size()> secondPlayer.size())
        {
            System.out.println("First player win!");
        }else{
            System.out.println("Draw!");
        }
    }
    private static Integer getTopValueFromPlayers(LinkedHashSet<Integer> player)
    {
        for(Integer i:player)
        {
            return i;//vzimame purvata i q vrushtame sled tova krai
        }
        return 0;//ako ne vzeme i ne vurne nishto vrushtame 0
    }
}
