package ADVANCED.SetsAndMapsAdvancedLab;

import java.util.*;

public class CitiesbyContinentandCountry07 {
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        int n=Integer.parseInt(scanner.nextLine());
        Map<String, Map<String, List<String>>> sum=new LinkedHashMap<>();
        for(int i=0;i<n;i++)
        {
            String[] input=scanner.nextLine().split("\\s+");
            String continent=input[0];
            String country=input[1];
            String capital=input[2];

            sum.putIfAbsent(continent,new LinkedHashMap<>());//ako nqma slagame kontinent i sreshtu nego mu suzdavame edin nov map

            Map<String, List<String>> map = sum.get(continent);//vze li sme value-to na continenta,koito e map

            map.putIfAbsent(country,new ArrayList<>());//v tozi map na continenta,ako nqma dadenata durjava q slagame

            List<String> list = map.get(country);//vzemame lista s gradove na stranata
            list.add(capital);//dobavq grada v tozi list
        }
        sum.entrySet()
                .stream()
                .forEach(e-> {
                    System.out.println(e.getKey()+":");
                    e.getValue().entrySet()
                            .stream()
                            .forEach(ie-> {
                                System.out.println("  "+ie.getKey()+" -> "+
                                        String.join(", ",ie.getValue()));
                            });
                });
    }
}
