package ADVANCED.SetsAndMapsAdvancedLab;

import java.util.*;
import java.util.stream.Collectors;

public class AcademyGraduation08 {
    /*
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int n = Integer.parseInt(scanner.nextLine());
        TreeMap<String,double[]> graduationList=new TreeMap<>();

        for(int i=0;i<n;i++)
        {
            String name= scanner.nextLine();
            double[] num= Arrays.stream(scanner.nextLine().split("\\s+"))
                    .mapToDouble(Double::parseDouble).toArray();
            graduationList.put(name,num);

        }
        /*
        for(var entry: graduationList.entrySet())
        {
            double avg=Arrays.stream(entry.getValue()).average().orElse(0);
            System.out.printf("%s is graduated with %f%n",entry.getKey(),avg);
        }
        /*
        graduationList.forEach((k,v)->{
            System.out.printf("%s is graduated with %f%n",k,Arrays.stream(v).average().orElse(0));
        });

         */



    /*
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int n = Integer.parseInt(scanner.nextLine());
        Map<String,double[]> graduationList=new TreeMap<>();

        for(int i=0;i<n;i++)
        {
            String name= scanner.nextLine();
            double[] num= Arrays.stream(scanner.nextLine().split("\\s+"))
                    .mapToDouble(Double::parseDouble).toArray();
            graduationList.put(name,num);
            /*
            double sum=0;

            for (double nu:num) {
                sum+=nu;
            }
            System.out.print(name +" is graduated with "+sum/num.length);
            System.out.println();

             */

        /*
        graduationList.entrySet()
                .stream()
                .forEach(s->{
                   // System.out.print(s+" is graduated with ");
                    System.out.printf("%s is graduated with ",s.getKey());
                    ;
                    int size=s.getValue().length;
                    System.out.print(Arrays.stream(s.getValue()).sum()/size);
                    System.out.println();

                });
       // Set<Double> sum=new HashSet<Double>(graduationList.values());

         */
        public static void main(String[] args) {
            Scanner scanner=new Scanner(System.in);
            Map<String,List<Double>> map=new TreeMap<>();
            int n=Integer.parseInt(scanner.nextLine());
            String name="";
            for(int i=0;i<n*2;i++)
            {
                if(i%2==0)
                {
                    name= scanner.nextLine();
                }else{
                    List<Double> grades=Arrays.stream(scanner.nextLine().split("\\s+"))
                            .map(Double::parseDouble).collect(Collectors.toList());
                    map.put(name,grades);
                }
            }

            for(String student:map.keySet())
            {
                double sum=0d;
                for(int i=0;i<map.get(student).size();i++)
                {
                    double currentSum=map.get(student).get(i);
                    sum+=currentSum;
                }
                double avg=sum/map.get(student).size();
                System.out.println(student+" is graduated with "+avg);
            }
        }
}

