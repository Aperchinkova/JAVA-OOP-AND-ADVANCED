package ADVANCED.SetsAndMapsAdvancedLab;

import java.util.*;

public class CountRealNumbers04 {
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        double[] values= Arrays.stream(scanner.nextLine().split("\\s+"))
                .mapToDouble(Double::parseDouble)
                .toArray();
        Map<Double,Integer> numbers=new LinkedHashMap<>();
        for (double v:values)
        {
            if(!numbers.containsKey(v))
            {
                numbers.put(v,1);
            }else{
                numbers.put(v,numbers.get(v)+1);
            }
        }
        for (Double key: numbers.keySet()) {
            System.out.printf("%.1f -> %d%n",key,numbers.get(key));
        }
    }
}
