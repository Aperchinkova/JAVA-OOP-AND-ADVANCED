package ADVANCED.SetsAndMapsAdvancedLab;

import java.util.LinkedHashSet;
import java.util.Scanner;

public class ParkingLot01 {
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        String command= scanner.nextLine();
        LinkedHashSet<String> cars=new LinkedHashSet<>();
        while(!command.equals("END"))
        {
            String[] parts=command.split(", ");

            if(parts[0].equals("IN"))
            {
                cars.add(parts[1]);
            }else if(parts[0].equals("OUT"))
            {
                cars.remove(parts[1]);
            }

            command= scanner.nextLine();
        }
        if(cars.isEmpty())
        {
            System.out.println("Parking Lot is Empty");
        }
        for (String s:cars)
        {
            System.out.println(s);
        }
    }
}
