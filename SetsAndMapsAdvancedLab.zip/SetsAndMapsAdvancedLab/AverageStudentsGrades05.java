package ADVANCED.SetsAndMapsAdvancedLab;

import java.util.*;

public class AverageStudentsGrades05 {
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        int n=Integer.parseInt(scanner.nextLine());
        Map<String, ArrayList<Double>> students=new TreeMap<>();
        for(int i=0;i<n;i++)
        {
            String[] studentInfo=scanner.nextLine().split("\\s+");
            String name=studentInfo[0];
            double grade=Double.parseDouble(studentInfo[1]);
            ArrayList<Double> grades=new ArrayList<>();
            if(!students.containsKey(name))
            {
                grades.add(grade);
                students.put(name,grades);
            }else{
                students.get(name).add(grade);
            }
        }
        /*
        for (Map.Entry<String,ArrayList<Double>> entry: students.entrySet())
        {
            LinkedHashSet<Double> grades=new LinkedHashSet<>(entry.getValue());
            double sum=0;
            for(Double d: entry.getValue())
            {
                sum+=d;
            }

           // double l=Arrays.stream(entry.getValue().stream().mapToDouble(Double::parseDouble).toArray());
            System.out.printf("%s -> %s (avg: %.2f)%n",entry.getKey(),s,sum/ grades.size());

        }

         */
        students.entrySet()
                .stream()
                .forEach(entry->{
                    double sum=0;
                    for(int i=0;i<entry.getValue().size();i++)
                    {
                        sum+=entry.getValue().get(i);
                    }
                    double avgSum=sum/entry.getValue().size();
                    System.out.print(entry.getKey()+" -> ");
                    entry.getValue().forEach(e-> System.out.printf("%.2f ",e));
                    System.out.printf("(avg: %.2f)%n",avgSum);
                });
    }
}
