package ADVANCED.SetsAndMapsAdvancedLab;

import java.util.*;

public class SoftUniParty02 {
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);

        Set<String> guests=new TreeSet<>();
        String input= scanner.nextLine();
        while(!input.equals("PARTY"))
        {
            guests.add(input);
            input= scanner.nextLine();
        }
        String guestss= scanner.nextLine();
        while (!guestss.equals("END"))
        {

            guests.remove(guestss);
            guestss= scanner.nextLine();
        }

        System.out.println(guests.size());
        System.out.println(String.join(System.lineSeparator(),guests));
    }
}
