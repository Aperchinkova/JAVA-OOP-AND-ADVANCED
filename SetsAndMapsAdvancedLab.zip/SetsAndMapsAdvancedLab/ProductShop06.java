package ADVANCED.SetsAndMapsAdvancedLab;

import java.util.*;

public class ProductShop06 {
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        String input= scanner.nextLine();
        Map<String, Map<String,Double>> shops=new TreeMap<>();
        while(!input.equals("Revision"))
        {
            String[] parts=input.split(", ");
            String shop=parts[0];
            String product=parts[1];
            double price=Double.parseDouble(parts[2]);
            Map<String,Double> products=new LinkedHashMap<>();
            if(!shops.containsKey(shop))
            {
                products.put(product,price);
                shops.put(shop,products);
            }else{
                products.put(product,price);
                shops.get(shop)
                        .put(product,price);
            }
            input= scanner.nextLine();
        }
        /*
        shops.entrySet()
                .stream()
                .forEach(entry -> {
                    System.out.print(entry.getKey()+"->");
                    System.out.println();
                    entry.getValue().entrySet()
                            .stream()
                            .forEach(e->{
                                System.out.print("Product: "+e.getKey()+", ");
                                System.out.printf("Price: %.1f",e.getValue());
                                System.out.println();
                            });
                });

         */
        for(String shop:shops.keySet())//keyset ni vrushra klyuchovete na mapa toest magazinite
        {
            System.out.println(shop+"->");
            for (var entry:shops.get(shop).entrySet())
            {
                System.out.printf("Product: %s, Price: %.1f%n",entry.getKey(),entry.getValue());
            }
        }

    }
}
