package carshopExtend;

public interface Rentable extends Car{

    public abstract Integer getMinRentDay();
    public abstract Double getPricePerDay();

}
