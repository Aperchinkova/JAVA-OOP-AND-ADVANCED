package carshopExtend;

public interface Sellable extends Car{
    public abstract Double getPrice();
}
