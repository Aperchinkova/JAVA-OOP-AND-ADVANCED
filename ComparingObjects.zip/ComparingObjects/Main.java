package ComparingObjects;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        String input= scanner.nextLine();
        List<Person> people=new ArrayList<>();
        int allPeopleCount=0;
        while (!input.equals("END"))
        {

            String[] parts=input.split("\\s+");
            String name=parts[0];
            int age=Integer.parseInt(parts[1]);
            String town=parts[2];
            Person person=new Person(name,age,town);
            people.add(person);
            allPeopleCount++;
            input= scanner.nextLine();
        }
        int n=Integer.parseInt(scanner.nextLine());
        Person searchedPerson=people.get(n-1);
        people.remove(searchedPerson);
        int count=0;
        for(Person person:people)
        {
            if(searchedPerson.compareTo(person)==0){
                count++;
            }

        }
        if(count==0)
        {
            System.out.println("No matches");
        }else{
            System.out.printf("%d %d %d",count+1,allPeopleCount-(count+1),allPeopleCount);
        }

    }
}
