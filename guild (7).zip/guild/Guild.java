package guild;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.stream.Collectors;

public class Guild {
    private Map<String,Player> roster;
    private String name;
    private int capacity;

    public Guild(String name, int capacity) {
        this.name = name;
        this.capacity = capacity;
        this.roster=new LinkedHashMap<>();
    }
    public void addPlayer(Player player){
        if(this.roster.size()<capacity)
        {
            roster.putIfAbsent(player.getName(), player);
        }
    }
    public boolean removePlayer(String name){
        for (Player player:roster.values()){
            if(player.getName().equals(name)){
                roster.remove(player.getName());
                return true;
            }
        }
        return false;
    }
    public void promotePlayer(String name){
        for(Player player:roster.values()){
            if(player.getName().equals(name)){
                player.setRank("Member");
            }
        }
    }
    public void demotePlayer(String name){
        for(Player player:roster.values()){
            if(player.getName().equals(name)){
                player.setRank("Trial");
            }
        }
    }

    public Player[] kickPlayersByClass(String clazz){
        Player[] array=roster.values().stream()
                .filter(player -> clazz.equals(player.getClazz()))
                .toArray(Player[]::new);
        for(Player player:array){
            roster.remove(player.getName());
        }
        return array;
    }

    public int count(){
        return roster.size();
    }
    public String report() {
        return String.format(
                "Players in the guild: %s:%n%s", name,
                roster.values().stream()
                        .map(Player::toString)
                        .collect(Collectors.joining(System.lineSeparator())));
    }
}
